# 智链先知 - 系统架构 Mermaid 图表

## 📊 图表 1：系统功能架构图

```mermaid
flowchart TB
    subgraph 数据层
        A1[OKX 官方 API]
        A2[实时价格数据]
        A3[K 线历史数据]
        A4[订单簿数据]
        A5[成交数据]
        A6[账户数据]
    end
    
    subgraph 处理层
        B1[数据缓存模块<br/>1-5 秒缓存]
        B2[技术指标计算<br/>RSI/乖离率/趋势/量能]
        B3[情绪分析模块<br/>交易/订单簿/动量情绪]
        B4[策略引擎<br/>SMA/动量/均值回归]
        B5[置信度计算<br/>9 维度加权融合]
    end
    
    subgraph 风控层
        C1[硬编码风控<br/>不可突破]
        C2[单笔止损 -3%]
        C3[单笔止盈 +6%]
        C4[每日止损 -10%]
        C5[最大仓位 50%]
        C6[置信度≥75%]
    end
    
    subgraph 展示层
        D1[实时价格显示<br/>秒级更新]
        D2[技术指标卡片<br/>RSI/乖离率/趋势/量能]
        D3[情绪分析卡片<br/>分数/状态/原因]
        D4[置信度显示<br/>9 维度综合]
        D5[控制面板<br/>启动/停止/查看]
        D6[运行日志<br/>实时记录]
    end
    
    A1 --> A2 & A3 & A4 & A5 & A6
    A2 & A3 & A4 & A5 & A6 --> B1
    B1 --> B2 & B3 & B4
    B2 & B3 & B4 --> B5
    B5 --> C1
    C1 --> C2 & C3 & C4 & C5 & C6
    C6 --> D1 & D2 & D3 & D4 & D5 & D6
    
    style A1 fill:#0052ff,stroke:#333,stroke-width:2px,color:#fff
    style B5 fill:#0ecb81,stroke:#333,stroke-width:2px,color:#fff
    style C1 fill:#f6465d,stroke:#333,stroke-width:2px,color:#fff
    style D1 fill:#10141d,stroke:#333,stroke-width:2px,color:#fff
    style D2 fill:#10141d,stroke:#333,stroke-width:2px,color:#fff
    style D3 fill:#10141d,stroke:#333,stroke-width:2px,color:#fff
```

---

## 📊 图表 2：创新点分析图

```mermaid
mindmap
  root((智链先知<br/>创新点))
    100% 真实数据
      ::icon(fa fa-check)
      零随机数
      OKX 官方 API
      实时数据源
    情绪分析模块
      ::icon(fa fa-heart)
      交易情绪 30%
      订单簿情绪 20%
      价格动量 15%
      市场情绪量化
    硬编码风控
      ::icon(fa fa-shield)
      不可突破
      单笔止损 -3%
      单笔止盈 +6%
      每日止损 -10%
    多策略融合
      ::icon(fa fa-layer-group)
      6 维度加权
      SMA 交叉 15%
      动量策略 15%
      均值回归 15%
      技术指标 10%
      订单流 10%
      量能 5%
      情绪 10%
    实时可视化
      ::icon(fa fa-chart-line)
      秒级更新
      价格实时更新
      指标实时计算
      情绪实时分析
```

---

## 📊 图表 3：传统工具 vs 智链先知对比

```mermaid
flowchart LR
    subgraph 传统交易工具
        A1[单一数据源系统]
        A2[简单技术指标分析]
        A3[建议可信度较低]
        A4[风控规则可配置]
        A5[使用模拟数据]
        A6[忽略市场情绪]
        A7[手动更新]
    end
    
    subgraph 智链先知
        B1[多数据源系统]
        B2[6 维度加权融合分析]
        B3[建议可信度更高]
        B4[风控规则硬编码]
        B5[100% 真实数据]
        B6[多维度情绪量化]
        B7[秒级自动更新]
    end
    
    A1 -.->|升级 | B1
    A2 -.->|升级 | B2
    A3 -.->|提升 | B3
    A4 -.->|强化 | B4
    A5 -.->|替换 | B5
    A6 -.->|增加 | B6
    A7 -.->|优化 | B7
    
    style A1 fill:#f6465d,stroke:#333,stroke-width:1px,color:#fff
    style A2 fill:#f6465d,stroke:#333,stroke-width:1px,color:#fff
    style A3 fill:#f6465d,stroke:#333,stroke-width:1px,color:#fff
    style A4 fill:#f6465d,stroke:#333,stroke-width:1px,color:#fff
    style A5 fill:#f6465d,stroke:#333,stroke-width:1px,color:#fff
    style A6 fill:#f6465d,stroke:#333,stroke-width:1px,color:#fff
    style A7 fill:#f6465d,stroke:#333,stroke-width:1px,color:#fff
    style B1 fill:#0ecb81,stroke:#333,stroke-width:2px,color:#fff
    style B2 fill:#0ecb81,stroke:#333,stroke-width:2px,color:#fff
    style B3 fill:#0ecb81,stroke:#333,stroke-width:2px,color:#fff
    style B4 fill:#0ecb81,stroke:#333,stroke-width:2px,color:#fff
    style B5 fill:#0ecb81,stroke:#333,stroke-width:2px,color:#fff
    style B6 fill:#0ecb81,stroke:#333,stroke-width:2px,color:#fff
    style B7 fill:#0ecb81,stroke:#333,stroke-width:2px,color:#fff
```

---

## 📊 图表 4：置信度计算流程图

```mermaid
flowchart LR
    subgraph 数据输入
        A1[OKX 实时数据]
    end
    
    subgraph 9 维度分析
        B1[SMA 交叉策略<br/>15%]
        B2[动量策略<br/>15%]
        B3[均值回归<br/>15%]
        B4[趋势分析<br/>10%]
        B5[乖离率<br/>10%]
        B6[RSI 指标<br/>10%]
        B7[订单流<br/>10%]
        B8[量能<br/>5%]
        B9[情绪<br/>10%]
    end
    
    subgraph 加权计算
        C1[加权求和]
        C2[信号一致性加分]
        C3[限制 0-100 范围]
    end
    
    subgraph 输出
        D1[置信度分数]
        D2{≥75%?}
        D3[执行交易]
        D4[继续观望]
    end
    
    A1 --> B1 & B2 & B3 & B4 & B5 & B6 & B7 & B8 & B9
    B1 & B2 & B3 & B4 & B5 & B6 & B7 & B8 & B9 --> C1
    C1 --> C2
    C2 --> C3
    C3 --> D1
    D1 --> D2
    D2 -->|是 | D3
    D2 -->|否 | D4
    
    style D3 fill:#0ecb81,stroke:#333,stroke-width:2px,color:#fff
    style D4 fill:#f6465d,stroke:#333,stroke-width:2px,color:#fff
```

---

## 📊 图表 5：情绪分析模块详图

```mermaid
flowchart TB
    subgraph 情绪数据源
        A1[成交数据]
        A2[订单簿数据]
        A3[K 线数据]
    end
    
    subgraph 情绪计算
        B1[交易情绪 30%]
        B2[订单簿情绪 20%]
        B3[价格动量情绪 15%]
    end
    
    subgraph 交易情绪计算
        C1[主动买入占比]
        C2[买入量占比]
        C3[>65% 偏多]
        C4[<35% 偏空]
    end
    
    subgraph 订单簿情绪计算
        C5[买单深度]
        C6[卖单深度]
        C7[>80% 支撑强]
        C8[<20% 压力大]
    end
    
    subgraph 价格动量计算
        C9[近 10 根 K 线]
        C10[涨跌比]
        C11[6 涨 4 跌 偏多]
        C12[4 涨 6 跌 偏空]
    end
    
    subgraph 情绪输出
        D1[情绪分数<br/>-1 到 +1]
        D2[情绪状态<br/>7 级分类]
        D3[情绪原因<br/>标签展示]
    end
    
    A1 --> B1
    A2 --> B2
    A3 --> B3
    
    B1 --> C1 & C2
    C1 & C2 --> C3 & C4
    
    B2 --> C5 & C6
    C5 & C6 --> C7 & C8
    
    B3 --> C9 & C10
    C9 & C10 --> C11 & C12
    
    C3 & C4 & C7 & C8 & C11 & C12 --> D1
    D1 --> D2 & D3
    
    style D1 fill:#0052ff,stroke:#333,stroke-width:2px,color:#fff
    style D2 fill:#0ecb81,stroke:#333,stroke-width:2px,color:#fff
    style D3 fill:#f0b90b,stroke:#333,stroke-width:2px,color:#fff
```

---

## 📊 图表 6：硬编码风控体系

```mermaid
flowchart TB
    subgraph 风控规则
        A1[硬编码风控<br/>不可突破]
    end
    
    subgraph 交易前检查
        B1[置信度≥75%?]
        B2[单笔仓位≤10%?]
        B3[总仓位≤50%?]
    end
    
    subgraph 交易中监控
        C1[实时盈亏计算]
        C2[止损 -3% 触发?]
        C3[止盈 +6% 触发?]
    end
    
    subgraph 日终检查
        D1[每日盈亏计算]
        D2[日损≥10%?]
        D3[停止交易 24h]
    end
    
    subgraph 执行结果
        E1[✅ 允许交易]
        E2[❌ 拒绝交易]
        E3[⚠️ 强制平仓]
        E4[⏸️ 暂停交易]
    end
    
    A1 --> B1 & B2 & B3
    B1 & B2 & B3 -->|全部通过 | E1
    B1 & B2 & B3 -->|任一失败 | E2
    
    E1 --> C1
    C1 --> C2 & C3
    C2 -->|是 | E3
    C3 -->|是 | E3
    C2 & C3 -->|否 | D1
    
    D1 --> D2
    D2 -->|是 | E4
    D2 -->|否 | E1
    
    style A1 fill:#f6465d,stroke:#333,stroke-width:3px,color:#fff
    style E1 fill:#0ecb81,stroke:#333,stroke-width:2px,color:#fff
    style E2 fill:#f6465d,stroke:#333,stroke-width:2px,color:#fff
    style E3 fill:#f0b90b,stroke:#333,stroke-width:2px,color:#fff
    style E4 fill:#848e9c,stroke:#333,stroke-width:2px,color:#fff
```

---

## 📊 图表 7：实时数据更新流程

```mermaid
sequenceDiagram
    participant OKX as OKX 官方 API
    participant Cache as 数据缓存层
    participant Calc as 计算引擎
    participant UI as 前端界面
    
    loop 每 1 秒
        OKX->>Cache: 价格数据
        Cache->>Calc: 传递价格
        Calc->>UI: 更新价格显示
    end
    
    loop 每 2 秒
        OKX->>Cache: 订单簿数据
        Cache->>Calc: 传递订单簿
        Calc->>UI: 更新情绪分析
    end
    
    loop 每 3 秒
        OKX->>Cache: 成交数据
        Cache->>Calc: 传递成交
        Calc->>UI: 更新情绪原因
    end
    
    loop 每 5 秒
        OKX->>Cache: K 线数据
        Cache->>Calc: 传递 K 线
        Calc->>Calc: 计算技术指标<br/>RSI/乖离率/趋势/量能
        Calc->>UI: 更新技术指标
    end
    
    loop 每 3 秒
        Calc->>Calc: 9 维度置信度计算
        Calc->>UI: 更新置信度
    end
    
    Note over OKX,UI: 所有数据 100% 真实<br/>零随机数
```

---

## 📋 使用指南

### 在 Markdown 中使用
```markdown
```mermaid
[图表代码]
```
```

### 在线渲染
- **GitHub** - 原生支持 Mermaid
- **Mermaid Live Editor** - https://mermaid.live/
- **VS Code** - 安装 Mermaid 插件

### 导出图片
1. 打开 https://mermaid.live/
2. 粘贴图表代码
3. 点击"Actions" → "Export PNG/SVG"

---

## 📊 图表说明

| 图表 | 用途 | 场景 |
|------|------|------|
| **图表 1** | 系统功能架构 | 技术文档、架构说明 |
| **图表 2** | 创新点分析 | 项目介绍、路演 PPT |
| **图表 3** | 传统 vs 智链先知 | 对比分析、优势展示 |
| **图表 4** | 置信度计算流程 | 技术细节、算法说明 |
| **图表 5** | 情绪分析模块 | 功能详解、模块说明 |
| **图表 6** | 硬编码风控体系 | 风控说明、安全保障 |
| **图表 7** | 实时数据更新流程 | 时序图、数据流说明 |

---

## 🎯 老许，这些图表可以用在：

1. **研究报告** - 插入 Mermaid 图表
2. **答辩 PPT** - 导出为 PNG/SVG
3. **技术文档** - 直接嵌入 Markdown
4. **项目展示** - 可视化系统架构

**需要我调整或添加其他图表吗？** 🚀
