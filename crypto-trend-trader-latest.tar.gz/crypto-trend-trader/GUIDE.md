# 项目 B - 可视化交易机器人

**版本：** 2.0.0 (可视化版本)  
**创建时间：** 2026-03-16  
**作者：** 老许

---

## 🎯 功能特性

### ✅ 已实现

1. **Web3 钱包管理**
   - 钱包地址显示
   - USDC/POL 余额查询
   - Polygon 网络连接

2. **策略配置**
   - 4 大策略权重配置
   - 实时调整策略参数
   - 策略启用/禁用

3. **执行控制**
   - 一键启动/停止
   - 实时状态监控
   - 自动风控检查

4. **状态监控**
   - 账户余额实时显示
   - 活跃持仓展示
   - 今日盈亏统计

5. **交易历史**
   - 完整交易记录
   - 盈亏统计
   - 导出功能

6. **实时日志**
   - 机器人运行日志
   - 错误告警
   - 交易通知

---

## 🚀 快速开始

### 1. 安装依赖

```bash
cd /root/.openclaw/workspace/crypto-trend-trader
npm install
```

### 2. 配置环境变量

```bash
cp .env.example .env
nano .env
```

**必填配置：**
```bash
# 钱包私钥
PRIVATE_KEY=your_private_key_here

# 钱包地址（用于显示）
WALLET_ADDRESS=0xYourWalletAddress

# Polymarket API
GAMMA_API_URL=https://gamma-api.polymarket.com
CLOB_API_URL=https://clob.polymarket.com

# Web 界面端口
WEB_PORT=3000

# 风控参数
MAX_POSITION_PERCENT=10
DAILY_STOP_LOSS=20
MAX_CONCURRENT_POSITIONS=5
STOP_LOSS_PERCENT=50
```

### 3. 启动机器人

```bash
npm start
```

启动后会显示：
```
🚀 交易机器人启动...
🌐 控制界面：http://localhost:3000
✅ 机器人运行中...
```

### 4. 访问控制界面

打开浏览器访问：**http://localhost:3000**

---

## 🖥️ 界面说明

### 机器人状态卡片
- **运行状态**：显示机器人是否运行
- **账户余额**：当前 USDC 余额
- **活跃持仓**：当前持仓数量
- **今日盈亏**：当日盈亏统计
- **控制按钮**：启动/停止机器人

### Web3 钱包卡片
- **网络**：显示当前网络（Polygon）
- **钱包地址**：连接的钱包地址
- **USDC 余额**：USDC 代币余额
- **POL 余额**：POL 代币余额（Gas 费）

### 策略配置卡片
- **趋势跟踪**：40% 权重
- **订单流分析**：30% 权重
- **事件驱动**：20% 权重
- **均值回归**：10% 权重

### 活跃持仓表格
- **市场**：交易的市场名称
- **方向**：YES/NO
- **入场价**：开仓价格
- **当前价**：当前市场价格
- **盈亏**：浮动盈亏

### 交易历史表格
- **时间**：交易时间
- **市场**：交易的市场
- **方向**：YES/NO
- **金额**：交易金额
- **结果**：盈利/亏损
- **盈亏**：具体盈亏金额

### 实时日志
- 显示机器人运行日志
- 交易执行通知
- 错误告警信息

---

## 📁 项目结构

```
crypto-trend-trader/
├── index.js                 # 主入口（集成 Web 服务器）
├── web-server.js            # Web 服务器
├── package.json             # 依赖管理
├── .env                     # 环境变量
├── .env.example             # 配置模板
├── README.md                # 使用文档
├── GUIDE.md                 # 详细指南（本文件）
├── public/
│   └── index.html           # 前端界面
├── src/
│   ├── strategy/            # 策略模块
│   │   ├── strategy-engine.js
│   │   ├── trend-strategy.js
│   │   ├── orderflow-strategy.js
│   │   ├── event-strategy.js
│   │   └── mean-reversion-strategy.js
│   ├── risk/                # 风控模块
│   │   └── risk-manager.js
│   ├── database/            # 数据库模块
│   │   └── database.js
│   └── utils/               # 工具模块
│       └── logger.js
├── config/                  # 配置文件
│   ├── principles.js
│   └── rules.js
├── test/                    # 测试文件
│   └── test.js
├── logs/                    # 日志目录
└── reports/                 # 报告目录
```

---

## 🛡️ 风控规则

| 参数 | 默认值 | 说明 |
|------|--------|------|
| 单笔仓位 | 10% | 每笔交易最大仓位 |
| 每日止损 | 20% | 单日最大亏损 |
| 同时持仓 | 5 个 | 最大并发交易数 |
| 单笔止损 | 50% | 每笔交易止损线 |
| 最大暴露 | 60% | 总资金最大使用率 |

---

## ⚙️ API 接口

### 获取状态
```
GET /api/status
```

**响应：**
```json
{
  "running": true,
  "balance": 100.50,
  "positions": 3,
  "dailyPnl": 2.30
}
```

### 启动机器人
```
POST /api/start
```

### 停止机器人
```
POST /api/stop
```

### 获取钱包信息
```
GET /api/wallet
```

### 获取策略配置
```
GET /api/strategies
```

### 更新策略配置
```
POST /api/strategies
```

### 获取持仓
```
GET /api/positions
```

### 获取交易历史
```
GET /api/trades
```

---

## 🔧 故障排除

### 无法访问界面
```bash
# 检查端口是否被占用
lsof -i :3000

# 更换端口
WEB_PORT=3001
```

### 依赖安装失败
```bash
# 清理缓存
npm cache clean --force

# 重新安装
rm -rf node_modules package-lock.json
npm install
```

### 钱包未连接
```bash
# 检查 .env 配置
cat .env | grep WALLET_ADDRESS

# 确保地址格式正确（0x 开头）
```

---

## 📞 支持

**作者：** 老许  
**版本：** 2.0.0  
**最后更新：** 2026-03-16

---

## ⚠️ 风险提示

- ⚠️ 二元交易风险高于传统交易
- ⚠️ 判断错误可能亏光本金
- ⚠️ 需要持续监控和调整
- ⚠️ 建议先小额测试
- ⚠️ 本软件仅供学习研究使用
