/**
 * 每日复盘脚本
 * 总结当日交易、分析盈亏、生成报告
 */

const { Database } = require('./src/database/database');
const { Logger } = require('./src/utils/logger');

class DailyReview {
  constructor() {
    this.db = new Database();
    this.logger = new Logger();
  }

  /**
   * 生成每日报告
   */
  async generateDailyReport() {
    const today = new Date().toISOString().split('T')[0];
    
    this.logger.info(`📊 生成 ${today} 每日报告...`);
    
    const trades = await this.db.getTradesByDate(today);
    const summary = this.calculateSummary(trades);
    const lessons = this.extractLessons(trades);
    
    const report = {
      date: today,
      summary,
      lessons,
      recommendations: this.generateRecommendations(summary, lessons)
    };
    
    this.saveReport(report);
    this.logger.info('✅ 每日报告已生成');
    
    return report;
  }

  /**
   * 计算总结
   */
  calculateSummary(trades) {
    const totalTrades = trades.length;
    const winningTrades = trades.filter(t => t.pnl > 0).length;
    const losingTrades = trades.filter(t => t.pnl < 0).length;
    const totalPnl = trades.reduce((sum, t) => sum + t.pnl, 0);
    const winRate = totalTrades > 0 ? (winningTrades / totalTrades * 100) : 0;
    
    return {
      totalTrades,
      winningTrades,
      losingTrades,
      totalPnl,
      winRate
    };
  }

  /**
   * 提取教训
   */
  extractLessons(trades) {
    const lessons = [];
    
    trades.forEach(trade => {
      if (trade.pnl < 0) {
        lessons.push({
          type: 'loss',
          marketId: trade.marketId,
          reason: this.analyzeLossReason(trade),
          improvement: this.suggestImprovement(trade)
        });
      }
    });
    
    return lessons;
  }

  /**
   * 分析亏损原因
   */
  analyzeLossReason(trade) {
    // 分析亏损原因
    return '入场时机不佳';
  }

  /**
   * 建议改进
   */
  suggestImprovement(trade) {
    // 生成改进建议
    return '等待更明确的信号';
  }

  /**
   * 生成建议
   */
  generateRecommendations(summary, lessons) {
    const recommendations = [];
    
    if (summary.winRate < 50) {
      recommendations.push('提高入场标准，等待更高质量的机会');
    }
    
    if (lessons.length > 3) {
      recommendations.push('减少交易频率，专注高概率机会');
    }
    
    return recommendations;
  }

  /**
   * 保存报告
   */
  saveReport(report) {
    const fs = require('fs');
    const path = require('path');
    
    const reportPath = path.join(__dirname, '..', 'reports', `daily-${report.date}.md`);
    
    const content = `# 每日交易报告 - ${report.date}

## 总结
- 总交易：${report.summary.totalTrades}
- 盈利：${report.summary.winningTrades}
- 亏损：${report.summary.losingTrades}
- 总盈亏：${report.summary.totalPnl}
- 胜率：${report.summary.winRate.toFixed(2)}%

## 教训
${report.lessons.map(l => `- ${l.marketId}: ${l.reason} → ${l.improvement}`).join('\n')}

## 建议
${report.recommendations.map(r => `- ${r}`).join('\n')}
`;
    
    fs.writeFileSync(reportPath, content);
  }
}

// 运行复盘
if (require.main === module) {
  const review = new DailyReview();
  review.generateDailyReport().catch(console.error);
}

module.exports = { DailyReview };
