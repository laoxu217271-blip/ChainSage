/**
 * OKX 实盘配置文件
 * 
 * ⚠️ 警告：这是实盘配置，使用真实资金！
 * ⚠️ 请务必先使用测试网测试！
 */

module.exports = {
  // OKX API 配置
  okx: {
    apiKey: '69eba943-da58-4ee5-b513-79540a32d7a7',
    apiSecret: '6CAB94AAB5848A8BFC045BF43C636576',
    passphrase: 'Openclawlaoxu888$',
    testnet: true                   // true=测试网，false=实盘 ⚠️ 实盘时改为 false
  },
  
  // 交易配置
  trading: {
    // 交易对
    symbols: ['BTC-USDT-SWAP', 'ETH-USDT-SWAP'],
    
    // 杠杆倍数（稳健型）
    leverage: {
      'BTC-USDT-SWAP': 10,  // BTC 10 倍杠杆
      'ETH-USDT-SWAP': 8    // ETH 8 倍杠杆
    },
    
    // 交易时间间隔（15 分钟）
    interval: 15 * 60 * 1000,
    
    // 最大持仓时间（4 小时）
    maxHoldTime: 4 * 60 * 60 * 1000
  },
  
  // 风控配置（稳健型）
  risk: {
    // 初始资金
    initialBalance: 10,  // 10 USDT
    
    // 单笔最大亏损（总资金的 3%）
    maxLossPerTrade: 0.03,
    
    // 每日最大亏损（总资金的 10%）
    maxLossPerDay: 0.10,
    
    // 最大仓位（总资金的 50%）
    maxPosition: 0.50,
    
    // 单笔仓位（总资金的 10%）
    positionSize: 0.10,
    
    // 止损比例（-3%）
    stopLoss: -0.03,
    
    // 止盈比例（+6%）
    takeProfit: 0.06,
    
    // 追踪止盈
    trailingStop: {
      enabled: true,
      threshold: 0.03  // 盈利 3% 后启动追踪止盈
    },
    
    // 连续亏损停止（3 次）
    maxConsecutiveLosses: 3,
    
    // 停止交易后恢复时间（24 小时）
    recoveryTime: 24 * 60 * 60 * 1000,
    
    // 紧急止损（总资金的 50%）
    emergencyStop: 0.50
  },
  
  // 策略配置
  strategy: {
    // 最小置信度（75% 才交易）
    minConfidence: 75,
    
    // 高置信度（90% 以上可以加大仓位）
    highConfidence: 90,
    
    // 多因子权重
    factors: {
      orderFlow: 0.40,    // 订单流 40%
      technical: 0.30,    // 技术指标 30%
      sentiment: 0.20,    // 情绪指标 20%
      poc: 0.10           // POC 分析 10%
    }
  },
  
  // 日志配置
  logging: {
    level: 'info',
    file: 'logs/live-trading.log',
    maxSize: '10MB',
    maxFiles: '7d'
  }
};
