#!/usr/bin/env node
/**
 * 获取最新预测结果
 * 用户上线时调用，输出最近的预测
 */

const fs = require('fs');
const path = require('path');

function getLatestPrediction() {
  const latestFile = path.join(__dirname, '../logs/latest-prediction.json');
  
  if (!fs.existsSync(latestFile)) {
    return null;
  }
  
  try {
    const data = JSON.parse(fs.readFileSync(latestFile, 'utf8'));
    return data;
  } catch (error) {
    return null;
  }
}

function formatPrediction(data) {
  if (!data) {
    return '⚠️ 暂无预测数据';
  }
  
  return `
📊 最新预测 (${data.timestamp})
============================================================
当前价格：$${data.currentPrice.toFixed(2)}
15 分钟涨跌：${data.change > 0 ? '+' : ''}${data.change}%

订单流分析:
  订单簿：买${data.bidVol.toFixed(2)} vs 卖${data.askVol.toFixed(2)}  比${data.ratio.toFixed(2)}${data.ratio>1.5?'✅ 买厚':data.ratio<0.67?'❌ 卖厚':'⚠️ 均衡'}
  大单：买${data.largeBuy.toFixed(2)} vs 卖${data.largeSell.toFixed(2)}  ${data.largeBuy>data.largeSell*1.5?'✅ 机构买':data.largeSell>data.largeBuy*1.5?'❌ 机构卖':'⚠️ 均衡'}
  Delta: ${data.delta>0?'+':''}${data.delta.toFixed(2)}  ${data.delta>100?'✅ 买方主动':data.delta<-100?'❌ 卖方主动':'⚠️ 均衡'}
  POC: $${data.poc.toFixed(2)}  当前价：$${data.currentPrice.toFixed(2)}  ${data.currentPrice>data.poc?'✅ 上方':'❌ 下方'}

🔮 预测:
  方向：${data.dir} ${data.dir==='看涨'?'⬆️':'⬇️'}
  置信度：${data.conf}%${data.conf<75?' ⚠️ 需谨慎':''}
  Polymarket 操作：${data.dir==='看涨'?'买入 YES':'买入 NO'}
  建议仓位：${data.conf>=80?'20%':data.conf>=70?'10%':'5%'}
  信号比：${data.bull}:${data.bear}
============================================================
`;
}

// 如果直接运行，输出最新预测
if (require.main === module) {
  const prediction = getLatestPrediction();
  console.log(formatPrediction(prediction));
}

module.exports = { getLatestPrediction, formatPrediction };
