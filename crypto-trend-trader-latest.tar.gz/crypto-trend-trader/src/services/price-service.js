/**
 * 价格数据服务
 * 从 OKX 获取实时价格和 K 线数据
 */

const axios = require('axios');

class PriceService {
  constructor() {
    this.okxAPI = 'https://www.okx.com/api/v5';
    this.cache = {};
    this.cacheExpiry = 5000;
  }

  async getPrice(symbol = 'BTC-USDT') {
    if (this.cache.btc && Date.now() - this.cache.timestamp < this.cacheExpiry) {
      return this.cache.btc;
    }

    try {
      const response = await axios.get(`${this.okxAPI}/market/ticker`, {
        params: { instId: symbol },
        timeout: 10000
      });

      const price = parseFloat(response.data.data[0].last);
      this.cache.btc = price;
      this.cache.timestamp = Date.now();

      return price;
    } catch (error) {
      console.error('获取价格失败:', error.message);
      return null;
    }
  }

  async getKlines(symbol = 'BTC-USDT', interval = '15m', limit = 100) {
    try {
      const response = await axios.get(`${this.okxAPI}/market/candles`, {
        params: { instId: symbol, bar: interval, limit },
        timeout: 10000
      });

      return response.data.data.map(k => ({
        timestamp: new Date(k[0]).getTime(),
        open: parseFloat(k[1]),
        high: parseFloat(k[2]),
        low: parseFloat(k[3]),
        close: parseFloat(k[4]),
        volume: parseFloat(k[5])
      }));
    } catch (error) {
      console.error('获取 K 线失败:', error.message);
      return [];
    }
  }
}

module.exports = { PriceService };
