/**
 * 快速分析器 - 5 秒内返回结果
 * 数据源：OKX
 */

const axios = require('axios');

class QuickAnalyzer {
  constructor() {
    this.timeout = 5000;
    this.okxAPI = 'https://www.okx.com/api/v5';
  }

  async analyze() {
    const startTime = Date.now();
    
    try {
      const [ticker, klines] = await Promise.all([
        axios.get(`${this.okxAPI}/market/ticker`, { 
          params: { instId: 'BTC-USDT' },
          timeout: this.timeout
        }),
        axios.get(`${this.okxAPI}/market/candles`, { 
          params: { instId: 'BTC-USDT', bar: '15m', limit: 50 },
          timeout: this.timeout
        })
      ]);
      
      const currentPrice = parseFloat(ticker.data.data[0].last);
      const closes = klines.data.data.map(k => parseFloat(k[4]));
      
      const ema7 = this.calculateEMA(closes, 7);
      const ema25 = this.calculateEMA(closes, 25);
      
      const trend = ema7 > ema25 ? 0.5 : -0.5;
      const confidence = Math.abs(ema7 - ema25) / ema25 > 0.01 ? 60 : 40;
      
      const result = {
        direction: trend > 0 ? 'YES' : 'NO',
        confidence,
        trend,
        price: currentPrice,
        time: Date.now() - startTime
      };
      
      console.log(`✅ 分析完成 (${result.time}ms)`);
      
      return result;
      
    } catch (error) {
      console.error('❌ 分析失败:', error.message);
      
      return {
        direction: 'WAIT',
        confidence: 0,
        trend: 0,
        price: 0,
        time: Date.now() - startTime,
        error: error.message
      };
    }
  }

  calculateEMA(prices, period) {
    const k = 2 / (period + 1);
    let ema = prices[0];
    for (let i = 1; i < prices.length; i++) {
      ema = prices[i] * k + ema * (1 - k);
    }
    return ema;
  }
}

module.exports = { QuickAnalyzer };
