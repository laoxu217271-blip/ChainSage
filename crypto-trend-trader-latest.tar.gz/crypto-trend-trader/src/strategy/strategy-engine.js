/**
 * 策略引擎 - 15 分钟趋势预测版本
 * 整合 4 大策略预测比特币未来 15 分钟走势
 */

const axios = require('axios');
const { TrendStrategy } = require('./trend-strategy');
const { OrderFlowStrategy } = require('./orderflow-strategy');
const { EventStrategy } = require('./event-strategy');
const { MeanReversionStrategy } = require('./mean-reversion-strategy');
const { SmartStopLoss } = require('./smart-stop-loss');

class StrategyEngine {
  constructor() {
    this.trendStrategy = new TrendStrategy();
    this.orderFlowStrategy = new OrderFlowStrategy();
    this.eventStrategy = new EventStrategy();
    this.meanReversionStrategy = new MeanReversionStrategy();
    
    // 策略权重
    this.weights = {
      trend: 0.40,
      orderFlow: 0.30,
      event: 0.20,
      meanReversion: 0.10
    };
    
    // 预测周期（15 分钟）
    this.predictionWindow = 15 * 60 * 1000; // 15 分钟毫秒数
  }

  /**
   * 初始化
   */
  async initialize() {
    await this.trendStrategy.initialize();
    await this.orderFlowStrategy.initialize();
    await this.eventStrategy.initialize();
    await this.meanReversionStrategy.initialize();
  }

  /**
   * 扫描市场（带重试机制）
   */
  async scanMarkets() {
    const markets = [];
    const maxRetries = 3;
    let lastError = null;
    
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        const response = await axios.get(`${process.env.GAMMA_API_URL}/markets`, {
          params: { closed: false },
          timeout: 30000,
          headers: {
            'User-Agent': 'Crypto-Trend-Trader/1.0'
          }
        });
        return response.data || [];
      } catch (error) {
        lastError = error;
        console.error(`扫描市场失败 (尝试 ${attempt}/${maxRetries}):`, error.message);
        if (attempt < maxRetries) {
          await this.sleep(2000 * attempt);
        }
      }
    }
    
    console.error('扫描市场最终失败:', lastError?.message);
    return [];
  }

  /**
   * 分析交易机会 - 15 分钟趋势预测版本
   */
  async analyzeOpportunities(markets) {
    const opportunities = [];
    
    // 筛选比特币相关市场
    const btcMarkets = markets.filter(m => 
      m.title && (
        m.title.toLowerCase().includes('bitcoin') ||
        m.title.toLowerCase().includes('btc')
      )
    );
    
    for (const market of btcMarkets) {
      // 4 大策略分析
      const trendSignal = await this.trendStrategy.analyze(market);
      const orderFlowSignal = await this.orderFlowStrategy.analyze(market);
      const eventSignal = await this.eventStrategy.analyze(market);
      const meanReversionSignal = await this.meanReversionStrategy.analyze(market);
      
      // 综合评分
      const score = (
        trendSignal.score * this.weights.trend +
        orderFlowSignal.score * this.weights.orderFlow +
        eventSignal.score * this.weights.event +
        meanReversionSignal.score * this.weights.meanReversion
      );
      
      // 生成 15 分钟预测
      const prediction = this.generatePrediction(score, market);
      
      // 如果置信度足够高，生成交易机会
      if (Math.abs(prediction.confidence) >= 0.7) {
        opportunities.push({
          marketId: market.id,
          title: market.title,
          direction: prediction.direction, // YES/NO
          confidence: prediction.confidence,
          predictedChange: prediction.predictedChange, // 预测涨跌幅
          predictionWindow: '15min',
          entryPrice: market.currentPrice,
          targetPrice: prediction.targetPrice,
          stopLoss: prediction.stopLoss,
          amount: this.calculatePositionSize(prediction.confidence)
        });
      }
    }
    
    return opportunities;
  }

  /**
   * 生成 15 分钟预测
   */
  generatePrediction(score, market) {
    const currentPrice = market.currentPrice || 0.50;
    
    // 方向判断
    let direction = 'NO';
    let predictedChange = 0;
    
    if (score > 0.3) {
      direction = 'YES';
      predictedChange = score * 3; // 预测上涨 0-3%
    } else if (score < -0.3) {
      direction = 'NO';
      predictedChange = score * 3; // 预测下跌 0-3%
    }
    
    // 置信度
    const confidence = Math.abs(score);
    
    // 目标价和止损
    const targetPrice = currentPrice + (direction === 'YES' ? 0.02 : -0.02);
    const stopLoss = currentPrice - (direction === 'YES' ? 0.005 : -0.005);
    
    return {
      direction,
      predictedChange: (predictedChange * 100).toFixed(2) + '%',
      confidence: confidence.toFixed(2),
      targetPrice: targetPrice.toFixed(4),
      stopLoss: stopLoss.toFixed(4)
    };
  }

  /**
   * 计算仓位大小
   */
  calculatePositionSize(confidence) {
    const basePercent = 0.10; // 基础 10%
    const adjustedPercent = basePercent * confidence;
    return Math.min(adjustedPercent, 0.20); // 最大 20%
  }

  /**
   * 执行交易
   */
  async execute(opportunity) {
    return {
      orderId: `order_${Date.now()}`,
      success: true,
      prediction: {
        direction: opportunity.direction,
        confidence: opportunity.confidence,
        predictedChange: opportunity.predictedChange,
        window: '15min'
      }
    };
  }

  /**
   * 延时函数
   */
  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

module.exports = { StrategyEngine };
