/**
 * 策略引擎 V2 - 改进版
 * 数据源：OKX
 */

const axios = require('axios');

class StrategyEngineV2 {
  constructor() {
    this.weights = {
      trend: 0.25,
      orderFlow: 0.35,
      volume: 0.25,
      sentiment: 0.15
    };
    
    this.minConfidence = 50;
    this.okxAPI = 'https://www.okx.com/api/v5';
  }

  async analyzeOpportunities() {
    try {
      const [ticker, klines, orderBook, trades] = await Promise.all([
        axios.get(`${this.okxAPI}/market/ticker`, { params: { instId: 'BTC-USDT' } }),
        axios.get(`${this.okxAPI}/market/candles`, { params: { instId: 'BTC-USDT', bar: '15m', limit: 100 } }),
        axios.get(`${this.okxAPI}/market/books`, { params: { instId: 'BTC-USDT', sz: '100' } }),
        axios.get(`${this.okxAPI}/market/trades`, { params: { instId: 'BTC-USDT', limit: '100' } })
      ]);

      const currentPrice = parseFloat(ticker.data.data[0].last);
      const closes = klines.data.data.map(k => parseFloat(k[4]));
      
      const trendScore = this.analyzeTrend(closes, currentPrice);
      const orderFlowScore = this.analyzeOrderFlow(orderBook.data.data[0], trades.data.data);
      const volumeScore = this.analyzeVolume(klines.data.data);
      const sentimentScore = this.analyzeSentiment(trades.data.data);
      
      const totalScore = (
        trendScore * this.weights.trend +
        orderFlowScore * this.weights.orderFlow +
        volumeScore * this.weights.volume +
        sentimentScore * this.weights.sentiment
      );
      
      const confidence = this.calculateConfidence(trendScore, orderFlowScore, volumeScore, sentimentScore);
      const direction = totalScore > 0 ? 'YES' : 'NO';
      
      const prediction = {
        direction,
        confidence,
        score: totalScore,
        signals: { trend: trendScore, orderFlow: orderFlowScore, volume: volumeScore, sentiment: sentimentScore },
        timestamp: new Date().toISOString()
      };
      
      console.log('\n📊 策略分析 V2:');
      console.log('  趋势得分:', trendScore.toFixed(2));
      console.log('  订单流:', orderFlowScore.toFixed(2));
      console.log('  成交量:', volumeScore.toFixed(2));
      console.log('  情绪:', sentimentScore.toFixed(2));
      console.log('  综合得分:', totalScore.toFixed(2));
      console.log('  置信度:', confidence + '%');
      console.log('  方向:', direction);
      console.log('  建议:', confidence >= this.minConfidence ? '✅ 可交易' : '⚠️ 观望');
      
      return prediction;
    } catch (error) {
      console.error('分析失败:', error.message);
      return null;
    }
  }

  analyzeTrend(closes, currentPrice) {
    const ema7 = this.calculateEMA(closes, 7);
    const ema25 = this.calculateEMA(closes, 25);
    const ema12 = this.calculateEMA(closes, 12);
    const ema26 = this.calculateEMA(closes, 26);
    const macd = ema12 - ema26;
    
    let score = 0;
    if (ema7 > ema25) score += 0.3; else score -= 0.3;
    if (macd > 0) score += 0.3; else if (macd < 0) score -= 0.3;
    
    const sma20 = closes.slice(-20).reduce((a,b) => a+b, 0) / 20;
    if (currentPrice > sma20) score += 0.2; else score -= 0.2;
    
    const trendStrength = Math.abs(ema7 - ema25) / ema25;
    if (trendStrength > 0.01) score += 0.2;
    
    return score;
  }

  analyzeOrderFlow(orderBook, trades) {
    const bidVol = orderBook.bids.slice(0,5).reduce((s,b) => s + parseFloat(b[1]), 0);
    const askVol = orderBook.asks.slice(0,5).reduce((s,a) => s + parseFloat(a[1]), 0);
    const ratio = bidVol / askVol;
    
    let score = 0;
    if (ratio > 2) score += 0.4; else if (ratio < 0.5) score -= 0.4;
    else if (ratio > 1.5) score += 0.2; else if (ratio < 0.67) score -= 0.2;
    
    const largeTrades = trades.filter(t => parseFloat(t.sz) > 0.5);
    const largeBuy = largeTrades.filter(t => t.side === 'buy').length;
    const largeSell = largeTrades.filter(t => t.side === 'sell').length;
    
    if (largeBuy > largeSell * 1.5) score += 0.3; else if (largeSell > largeBuy * 1.5) score -= 0.3;
    
    const activeBuy = trades.filter(t => t.side === 'buy').reduce((s,t) => s + parseFloat(t.sz), 0);
    const activeSell = trades.filter(t => t.side === 'sell').reduce((s,t) => s + parseFloat(t.sz), 0);
    const delta = activeBuy - activeSell;
    
    if (delta > 200) score += 0.3; else if (delta < -200) score -= 0.3;
    
    return score;
  }

  analyzeVolume(klines) {
    const volumes = klines.map(k => parseFloat(k[5]));
    const avgVolume = volumes.slice(0, -1).reduce((a,b) => a+b, 0) / (volumes.length - 1);
    const currentVolume = volumes[volumes.length - 1];
    const volumeRatio = currentVolume / avgVolume;
    
    if (volumeRatio > 1.5) return 0.4;
    if (volumeRatio > 1.2) return 0.2;
    if (volumeRatio < 0.8) return -0.2;
    return 0;
  }

  analyzeSentiment(trades) {
    const buyPressure = trades.filter(t => t.side === 'buy').length;
    const total = trades.length;
    const buyRatio = buyPressure / total;
    
    if (buyRatio > 0.7) return -0.3;
    if (buyRatio < 0.3) return 0.3;
    if (buyRatio > 0.55) return 0.2;
    if (buyRatio < 0.45) return -0.2;
    return 0;
  }

  calculateConfidence(trend, orderFlow, volume, sentiment) {
    let confidence = 50;
    confidence += trend * 30;
    confidence += orderFlow * 25;
    confidence += volume * 20;
    confidence += sentiment * 15;
    
    const signals = [trend, orderFlow, volume, sentiment];
    const positive = signals.filter(s => s > 0).length;
    const negative = signals.filter(s => s < 0).length;
    
    if (positive === 4 || negative === 4) confidence += 10;
    if (positive >= 3 || negative >= 3) confidence += 5;
    
    return Math.max(0, Math.min(100, Math.round(confidence)));
  }

  calculateEMA(prices, period) {
    const k = 2 / (period + 1);
    let ema = prices[0];
    for (let i = 1; i < prices.length; i++) {
      ema = prices[i] * k + ema * (1 - k);
    }
    return ema;
  }
}

module.exports = { StrategyEngineV2 };
