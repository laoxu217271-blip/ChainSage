/**
 * OKX 实盘交易主程序 - 完整交易执行版
 * ⚠️ 警告：这是实盘程序，使用真实资金！
 * ⚠️ 请务必先使用测试网测试！
 */

const config = require('../config-live');
const { OKXTrader } = require('./okx-trader');
const { Logger } = require('./utils/logger');

class OKXLiveTrader {
  constructor() {
    this.logger = new Logger();
    this.trader = null;
    this.isRunning = false;
    this.checkInterval = null;
    
    // 状态跟踪
    this.state = {
      balance: config.risk.initialBalance,
      dailyPnL: 0,
      consecutiveLosses: 0,
      totalTrades: 0,
      winTrades: 0,
      currentPositions: 0
    };
  }

  /**
   * 初始化
   */
  async init() {
    try {
      this.trader = new OKXTrader();
      
      // 获取账户余额
      const balance = await this.trader.getBalance();
      this.state.balance = balance.total;
      
      this.logger.info('✅ OKX 交易器初始化成功');
      this.logger.info(`💰 账户余额：${balance.total} USDT`);
      this.logger.info(`⚠️ 当前模式：${config.okx.testnet ? '测试网' : '实盘'}`);
      
      return true;
    } catch (error) {
      this.logger.error(`❌ 初始化失败：${error.message}`);
      return false;
    }
  }

  /**
   * 启动交易
   */
  async start() {
    const initialized = await this.init();
    if (!initialized) {
      this.logger.error('❌ 无法启动，初始化失败');
      return;
    }
    
    this.isRunning = true;
    this.logger.info('🚀 OKX 实盘交易启动');
    this.logger.info(`📊 杠杆：BTC ${config.trading.leverage['BTC-USDT-SWAP']}x, ETH ${config.trading.leverage['ETH-USDT-SWAP']}x`);
    this.logger.info(`⚠️ 风控：单笔最大亏损 ${config.risk.maxLossPerTrade*100}%, 每日最大亏损 ${config.risk.maxLossPerDay*100}%`);
    
    // 启动主循环
    await this.tradingLoop();
  }

  /**
   * 交易主循环
   */
  async tradingLoop() {
    while (this.isRunning) {
      try {
        // 1. 获取市场数据
        this.logger.info('📊 获取市场数据...');
        
        // 2. 生成交易信号
        this.logger.info('🤖 生成交易信号...');
        const signal = await this.generateSignal();
        
        // 3. 风控检查
        if (signal && this.riskCheck(signal)) {
          this.logger.info(`✅ 风控检查通过：${signal.instId} ${signal.side}`);
          
          // 4. 执行开仓
          const result = await this.trader.openPosition(signal);
          
          if (result.success) {
            this.state.totalTrades++;
            this.state.currentPositions++;
            this.logger.info(`✅ 开仓成功！订单 ID: ${result.orderId}`);
            
            // 5. 启动止盈止损监控
            this.startStopLossMonitor();
          } else {
            this.logger.error(`❌ 开仓失败：${result.error}`);
          }
        } else {
          this.logger.info('⚠️ 无交易信号或风控未通过');
        }
        
        // 6. 等待下一个周期（15 分钟）
        await this.sleep(config.trading.interval);
        
      } catch (error) {
        this.logger.error(`❌ 错误：${error.message}`);
        await this.sleep(60000); // 错误后等待 1 分钟
      }
    }
  }

  /**
   * 生成交易信号（使用策略引擎）
   */
  async generateSignal() {
    // 获取市场数据
    const ticker = await this.trader.getTicker('BTC-USDT-SWAP');
    if (!ticker) return null;
    
    // TODO: 集成完整策略引擎
    // 当前简化版：使用固定方向（实际应由策略引擎计算）
    
    // 简单示例：基于价格趋势判断
    const klines = await this.getKlines('BTC-USDT-SWAP', '15m', 50);
    if (!klines || klines.length < 2) return null;
    
    const currentPrice = klines[klines.length - 1].close;
    const prevPrice = klines[klines.length - 2].close;
    
    // 简单趋势判断
    const side = currentPrice > prevPrice ? 'buy' : 'sell';
    const size = '0.01'; // 0.01 BTC
    
    return {
      instId: 'BTC-USDT-SWAP',
      side,
      size,
      leverage: config.trading.leverage['BTC-USDT-SWAP'],
      stopLoss: config.risk.stopLoss,
      takeProfit: config.risk.takeProfit,
      confidence: 75 // 固定置信度（实际应由策略引擎计算）
    };
  }

  /**
   * 获取 K 线数据
   */
  async getKlines(instId, interval = '15m', limit = 50) {
    try {
      const axios = require('axios');
      const response = await axios.get('https://www.okx.com/api/v5/market/candles', {
        params: { instId, bar: interval, limit }
      });
      
      if (response.data.code === '0') {
        return response.data.data.map(k => ({
          timestamp: parseInt(k[0]),
          open: parseFloat(k[1]),
          high: parseFloat(k[2]),
          low: parseFloat(k[3]),
          close: parseFloat(k[4]),
          volume: parseFloat(k[5])
        }));
      }
      return null;
    } catch (error) {
      this.logger.error(`获取 K 线失败：${error.message}`);
      return null;
    }
  }

  /**
   * 风控检查
   */
  riskCheck(signal) {
    // 1. 检查每日止损
    if (this.state.dailyPnL <= -config.risk.maxLossPerDay * this.state.balance) {
      this.logger.warn('❌ 达到每日止损，停止交易');
      return false;
    }
    
    // 2. 检查连续亏损
    if (this.state.consecutiveLosses >= config.risk.maxConsecutiveLosses) {
      this.logger.warn('❌ 连续亏损次数过多，停止交易');
      return false;
    }
    
    // 3. 检查当前持仓
    if (this.state.currentPositions >= config.risk.maxConcurrentPositions) {
      this.logger.warn('❌ 达到最大持仓数，停止开仓');
      return false;
    }
    
    return true;
  }

  /**
   * 启动止盈止损监控
   */
  startStopLossMonitor() {
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
    }
    
    // 每 5 秒检查一次止盈止损
    this.checkInterval = setInterval(async () => {
      await this.trader.checkStopLoss();
      
      // 检查持仓状态
      const position = this.trader.getCurrentPosition();
      if (!position) {
        // 持仓已平，停止监控
        clearInterval(this.checkInterval);
        this.state.currentPositions--;
        this.logger.info('✅ 持仓已平，停止监控');
      }
    }, 5000);
    
    this.logger.info('✅ 止盈止损监控已启动');
  }

  /**
   * 停止交易
   */
  async stop() {
    this.logger.info('⏹️ 停止交易...');
    this.isRunning = false;
    
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
    }
    
    // 平掉所有持仓
    if (this.trader) {
      const position = this.trader.getCurrentPosition();
      if (position) {
        await this.trader.closePosition('停止交易');
      }
    }
    
    this.logger.info('✅ 交易已停止');
  }

  /**
   * 延时函数
   */
  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /**
   * 获取状态
   */
  getStatus() {
    return {
      isRunning: this.isRunning,
      balance: this.state.balance,
      dailyPnL: this.state.dailyPnL,
      totalTrades: this.state.totalTrades,
      winTrades: this.state.winTrades,
      currentPositions: this.state.currentPositions,
      consecutiveLosses: this.state.consecutiveLosses,
      tradeHistory: this.trader ? this.trader.getTradeHistory() : []
    };
  }
}

// 启动
if (require.main === module) {
  const trader = new OKXLiveTrader();
  
  process.on('SIGINT', async () => {
    await trader.stop();
    process.exit(0);
  });
  
  trader.start().catch(console.error);
}

module.exports = { OKXLiveTrader };
