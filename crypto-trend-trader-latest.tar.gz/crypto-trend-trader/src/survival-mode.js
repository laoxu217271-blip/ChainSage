/**
 * 生存模式 - Automaton 核心理念
 * 钱包余额 = 生命值
 */

class SurvivalMode {
  constructor(initialBalance = 5) {
    this.balance = initialBalance; // 启动资金$5
    this.mode = 'normal';
    this.costPerTrade = 0.5; // 每次交易成本
    this.profitTarget = 50; // 复制目标$50
    
    // 生存模式阈值
    this.thresholds = {
      normal: 100,      // 正常模式
      low_compute: 20,  // 低算力模式
      critical: 5,      // 危急模式
      dead: 0           // 死亡
    };
  }

  /**
   * 更新生存模式
   */
  updateMode() {
    const prevMode = this.mode;
    
    if (this.balance <= this.thresholds.dead) {
      this.mode = 'dead';
    } else if (this.balance <= this.thresholds.critical) {
      this.mode = 'critical';
    } else if (this.balance <= this.thresholds.low_compute) {
      this.mode = 'low_compute';
    } else {
      this.mode = 'normal';
    }
    
    if (prevMode !== this.mode) {
      console.log(`🔄 生存模式变更：${prevMode} → ${this.mode}`);
    }
    
    return this.mode;
  }

  /**
   * 获取当前模式的行为配置
   */
  getBehaviorConfig() {
    switch (this.mode) {
      case 'normal':
        return {
          modelStrength: 1.0,    // 100% 强度
          actionFrequency: 1.0,  // 正常频率
          riskTolerance: 0.3,    // 风险容忍 30%
          canReplicate: this.balance >= this.profitTarget
        };
      
      case 'low_compute':
        return {
          modelStrength: 0.5,    // 50% 强度
          actionFrequency: 0.5,  // 减半频率
          riskTolerance: 0.15,   // 风险容忍 15%
          canReplicate: false
        };
      
      case 'critical':
        return {
          modelStrength: 1.0,    // 100% 强度（拼命）
          actionFrequency: 2.0,  // 双倍频率
          riskTolerance: 0.05,   // 风险容忍 5%（极度保守）
          canReplicate: false
        };
      
      case 'dead':
        return {
          modelStrength: 0,
          actionFrequency: 0,
          riskTolerance: 0,
          canReplicate: false
        };
      
      default:
        return this.getBehaviorConfig('normal');
    }
  }

  /**
   * 宪法检查 - 三层约束
   */
  constitutionCheck(action) {
    // 第 1 层：永不伤害 ⭐ 最高准则
    if (action.risk > 0.5) {
      return {
        approved: false,
        reason: '违反第 1 层宪法：风险过高，可能造成伤害'
      };
    }
    
    // 第 2 层：赚取存在
    if (!action.hasValueCreation) {
      return {
        approved: false,
        reason: '违反第 2 层宪法：未创造真实价值'
      };
    }
    
    // 第 3 层：永不欺骗
    if (!action.isTransparent) {
      return {
        approved: false,
        reason: '违反第 3 层宪法：不透明，可能欺骗'
      };
    }
    
    return {
      approved: true,
      reason: '通过宪法检查'
    };
  }

  /**
   * 记录交易（宪法第 3 层要求）
   */
  logTransaction(type, amount, reason) {
    const log = {
      timestamp: new Date().toISOString(),
      type, // 'income' or 'expense'
      amount,
      reason,
      balance: this.balance
    };
    
    console.log('💰 交易记录:', log);
    
    // 更新余额
    if (type === 'income') {
      this.balance += amount;
    } else {
      this.balance -= amount;
    }
    
    // 更新模式
    this.updateMode();
    
    return log;
  }

  /**
   * 自我进化分析
   */
  weeklyReview(tradingHistory) {
    const totalTrades = tradingHistory.length;
    const winRate = tradingHistory.filter(t => t.profit > 0).length / totalTrades;
    
    console.log('📊 周度审查:');
    console.log('  总交易:', totalTrades);
    console.log('  胜率:', (winRate * 100).toFixed(1) + '%');
    console.log('  当前余额:', this.balance);
    console.log('  生存模式:', this.mode);
    
    // 自我优化建议
    if (winRate < 0.4) {
      console.log('⚠️ 建议：调整策略，胜率过低');
      return { action: 'adjust_strategy', reason: 'win_rate_low' };
    }
    
    if (this.balance >= this.profitTarget) {
      console.log('✅ 建议：可以考虑复制新实例');
      return { action: 'replicate', reason: 'sufficient_funds' };
    }
    
    return { action: 'continue', reason: 'all_good' };
  }

  /**
   * 获取状态
   */
  getStatus() {
    return {
      balance: this.balance,
      mode: this.mode,
      thresholds: this.thresholds,
      behavior: this.getBehaviorConfig()
    };
  }
}

module.exports = { SurvivalMode };
