/**
 * 日志工具 - 三语播报（繁体中文 + 英语）
 * 交易日志、错误日志、审计日志
 */

// 三语翻译字典
const TRANSLATIONS = {
  '启动交易': { 'zh-TW': '啟動交易', 'en': 'Start Trading' },
  '交易已启动': { 'zh-TW': '交易已啟動', 'en': 'Trading Started' },
  '停止交易': { 'zh-TW': '停止交易', 'en': 'Stop Trading' },
  '交易已停止': { 'zh-TW': '交易已停止', 'en': 'Trading Stopped' },
  '获取市场数据': { 'zh-TW': '獲取市場數據', 'en': 'Fetching Market Data' },
  '生成交易信号': { 'zh-TW': '生成交易信號', 'en': 'Generating Trading Signal' },
  '可交易': { 'zh-TW': '可交易', 'en': 'Tradable' },
  '观望': { 'zh-TW': '觀望', 'en': 'Watching' },
  '开仓': { 'zh-TW': '開倉', 'en': 'Open Position' },
  '平仓': { 'zh-TW': '平倉', 'en': 'Close Position' },
  '触发止损': { 'zh-TW': '觸發止損', 'en': 'Stop Loss Triggered' },
  '触发止盈': { 'zh-TW': '觸發止盈', 'en': 'Take Profit Triggered' },
  '置信度': { 'zh-TW': '置信度', 'en': 'Confidence' },
  '方向': { 'zh-TW': '方向', 'en': 'Direction' },
  '启动失败': { 'zh-TW': '啟動失敗', 'en': 'Start Failed' },
  '停止失败': { 'zh-TW': '停止失敗', 'en': 'Stop Failed' },
  '系统初始化完成': { 'zh-TW': '系統初始化完成', 'en': 'System Initialized' },
  '等待启动交易': { 'zh-TW': '等待啟動交易', 'en': 'Waiting to Start Trading' }
};

class Logger {
  constructor() {
    this.logFile = process.env.LOG_FILE || 'logs/trading.log';
    this.logLevel = process.env.LOG_LEVEL || 'info';
  }

  // 翻译为三语
  translate(message) {
    let zhTW = message;
    let en = message;

    for (const [zhCN, trans] of Object.entries(TRANSLATIONS)) {
      if (message.includes(zhCN)) {
        zhTW = trans['zh-TW'] || zhCN;
        en = trans['en'] || zhCN;
        break;
      }
    }

    return { 'zh-CN': message, 'zh-TW': zhTW, 'en': en };
  }

  // 格式化三语输出
  formatMessage(prefix, message) {
    const translated = this.translate(message);
    return `${prefix} [繁] ${translated['zh-TW']} | [Eng] ${translated['en']}`;
  }

  info(message, ...args) {
    console.log(this.formatMessage('[INFO]', message), ...args);
  }

  warn(message, ...args) {
    console.warn(this.formatMessage('[WARN]', message), ...args);
  }

  error(message, ...args) {
    console.error(this.formatMessage('[ERROR]', message), ...args);
  }

  debug(message, ...args) {
    if (this.logLevel === 'debug') {
      console.log(this.formatMessage('[DEBUG]', message), ...args);
    }
  }
}

module.exports = { Logger };
