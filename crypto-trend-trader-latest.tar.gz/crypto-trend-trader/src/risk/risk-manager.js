/**
 * 风控管理器
 * 仓位管理、止损止盈、每日止损
 */

class RiskManager {
  constructor() {
    this.maxPositionPercent = parseFloat(process.env.MAX_POSITION_PERCENT) || 10;
    this.dailyStopLoss = parseFloat(process.env.DAILY_STOP_LOSS) || 20;
    this.maxConcurrentPositions = parseInt(process.env.MAX_CONCURRENT_POSITIONS) || 5;
    this.stopLossPercent = parseFloat(process.env.STOP_LOSS_PERCENT) || 50;
    
    this.startOfDayBalance = null;
    this.currentBalance = null;
    this.currentPositions = 0;
  }

  /**
   * 初始化
   */
  async initialize() {
    this.startOfDayBalance = await this.getBalance();
    this.currentBalance = this.startOfDayBalance;
  }

  /**
   * 检查是否可以交易
   */
  canTrade() {
    const dailyLoss = this.startOfDayBalance - this.currentBalance;
    
    if (dailyLoss >= this.dailyStopLoss) {
      return false;
    }
    
    if (this.currentPositions >= this.maxConcurrentPositions) {
      return false;
    }
    
    return true;
  }

  /**
   * 批准交易
   */
  approveTrading(opportunities) {
    const approved = [];
    
    for (const opp of opportunities) {
      if (this.canTrade() && opp.confidence >= 0.7) {
        approved.push(opp);
        this.currentPositions++;
      }
    }
    
    return approved;
  }

  /**
   * 检查止损
   */
  async checkStopLoss(position) {
    const currentPrice = await this.getCurrentPrice(position.marketId);
    const entryPrice = position.entryPrice;
    
    if (position.direction === 'YES') {
      const lossPercent = (entryPrice - currentPrice) / entryPrice * 100;
      if (lossPercent >= this.stopLossPercent) {
        return true;
      }
    } else {
      const lossPercent = (currentPrice - entryPrice) / entryPrice * 100;
      if (lossPercent >= this.stopLossPercent) {
        return true;
      }
    }
    
    return false;
  }

  /**
   * 获取余额
   */
  async getBalance() {
    return 100;
  }

  /**
   * 获取当前价格
   */
  async getCurrentPrice(marketId) {
    return 0.50;
  }
}

module.exports = { RiskManager };
