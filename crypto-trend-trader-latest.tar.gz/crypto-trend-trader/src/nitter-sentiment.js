/**
 * Nitter 社交媒体情绪分析
 * 通过 Nitter RSS 读取 Twitter 推文，分析市场情绪
 */

const https = require('https');
const http = require('http');

class NitterSentiment {
  constructor() {
    // 关注的 Twitter 账号列表（加密货币相关）
    this.accounts = [
      'sopersone',
      'elonmusk',
      'VitalikButerin',
      'cz_binance',
      'aantonop'
    ];
    
    // Nitter 实例列表（防止单点故障）
    this.instances = [
      'https://nitter.net',
      'https://nitter.lucabased.xyz',
      'https://nitter.privacy.com.de'
    ];
  }

  /**
   * 从 Nitter 获取推文
   */
  async getTweets(username, limit = 10) {
    return new Promise((resolve, reject) => {
      const instance = this.instances[0];
      const url = `${instance}/${username}/rss`;
      
      console.log(`📰 读取 Nitter: ${url}`);
      
      http.get(url, (res) => {
        let data = '';
        
        res.on('data', (chunk) => {
          data += chunk;
        });
        
        res.on('end', () => {
          try {
            // 简单解析 RSS XML
            const tweets = this.parseRSS(data, limit);
            resolve(tweets);
          } catch (error) {
            reject(error);
          }
        });
      }).on('error', (error) => {
        reject(error);
      });
    });
  }

  /**
   * 解析 RSS XML
   */
  parseRSS(xml, limit) {
    const tweets = [];
    const items = xml.split('<item>').slice(1);
    
    for (let i = 0; i < Math.min(items.length, limit); i++) {
      const item = items[i];
      
      // 提取标题
      const titleMatch = item.match(/<title>(.*?)<\/title>/);
      const title = titleMatch ? titleMatch[1] : '';
      
      // 提取时间
      const pubDateMatch = item.match(/<pubDate>(.*?)<\/pubDate>/);
      const pubDate = pubDateMatch ? pubDateMatch[1] : '';
      
      // 提取链接
      const linkMatch = item.match(/<link>(.*?)<\/link>/);
      const link = linkMatch ? linkMatch[1] : '';
      
      tweets.push({
        title,
        pubDate,
        link,
        username: this.getCurrentUsername()
      });
    }
    
    return tweets;
  }

  /**
   * 分析推文情绪
   */
  analyzeSentiment(tweets) {
    let positiveCount = 0;
    let negativeCount = 0;
    let neutralCount = 0;
    
    const positiveKeywords = ['bullish', 'moon', 'up', 'rise', 'gain', 'profit', 'buy', 'long', 'green'];
    const negativeKeywords = ['bearish', 'crash', 'down', 'fall', 'loss', 'sell', 'short', 'red', 'dump'];
    
    tweets.forEach(tweet => {
      const text = (tweet.title + ' ' + tweet.description || '').toLowerCase();
      
      if (positiveKeywords.some(k => text.includes(k))) {
        positiveCount++;
      } else if (negativeKeywords.some(k => text.includes(k))) {
        negativeCount++;
      } else {
        neutralCount++;
      }
    });
    
    const total = tweets.length || 1;
    const sentimentScore = (positiveCount - negativeCount) / total;
    
    return {
      score: sentimentScore,
      positive: positiveCount,
      negative: negativeCount,
      neutral: neutralCount,
      total: total,
      status: this.getSentimentStatus(sentimentScore)
    };
  }

  /**
   * 获取情绪状态描述
   */
  getSentimentStatus(score) {
    if (score > 0.5) return '极度乐观';
    if (score > 0.2) return '乐观';
    if (score > 0) return '偏多';
    if (score < -0.5) return '极度悲观';
    if (score < -0.2) return '悲观';
    if (score < 0) return '偏空';
    return '中性';
  }

  /**
   * 获取当前用户名
   */
  getCurrentUsername() {
    return this.accounts[0];
  }

  /**
   * 综合情绪分析
   */
  async getOverallSentiment() {
    try {
      // 获取多个账号的推文
      const allTweets = [];
      
      for (const account of this.accounts.slice(0, 3)) {
        try {
          const tweets = await this.getTweets(account, 5);
          allTweets.push(...tweets);
        } catch (error) {
          console.error(`读取 ${account} 失败：${error.message}`);
        }
      }
      
      // 分析情绪
      const sentiment = this.analyzeSentiment(allTweets);
      
      console.log(`📊 社交媒体情绪分析:`);
      console.log(`  总推文：${sentiment.total}`);
      console.log(`  积极：${sentiment.positive}`);
      console.log(`  消极：${sentiment.negative}`);
      console.log(`  中性：${sentiment.neutral}`);
      console.log(`  情绪分数：${sentiment.score}`);
      console.log(`  情绪状态：${sentiment.status}`);
      
      return sentiment;
    } catch (error) {
      console.error(`情绪分析失败：${error.message}`);
      return {
        score: 0,
        status: '中性',
        positive: 0,
        negative: 0,
        neutral: 0,
        total: 0
      };
    }
  }
}

module.exports = { NitterSentiment };
