/**
 * OKX 交易执行器 - 负责实际下单和平仓
 * ⚠️ 实盘专用，使用真实资金！
 */

const crypto = require('crypto');
const axios = require('axios');
const config = require('../config-live');
const { Logger } = require('./utils/logger');

class OKXTrader {
  constructor() {
    this.logger = new Logger();
    this.apiKey = config.okx.apiKey;
    this.apiSecret = config.okx.apiSecret;
    this.passphrase = config.okx.passphrase;
    this.testnet = config.okx.testnet;
    
    // API 基础 URL
    this.baseURL = this.testnet 
      ? 'https://okx.com' 
      : 'https://www.okx.com';
    
    // 当前持仓
    this.currentPosition = null;
    
    // 交易记录
    this.tradeHistory = [];
  }

  /**
   * 生成签名
   */
  generateSignature(timestamp, method, path, body = '') {
    const signStr = timestamp + method + path + body;
    return crypto
      .createHmac('sha256', this.apiSecret)
      .update(signStr)
      .digest('base64');
  }

  /**
   * 发送 API 请求
   */
  async request(method, endpoint, params = {}, data = null) {
    const url = `${this.baseURL}/api/v5${endpoint}`;
    const timestamp = new Date().toISOString();
    const body = data ? JSON.stringify(data) : '';
    const queryString = Object.keys(params).map(k => `${k}=${params[k]}`).join('&');
    const path = endpoint + (queryString ? '?' + queryString : '');
    
    const signature = this.generateSignature(timestamp, method, path, body);
    
    const headers = {
      'OK-ACCESS-KEY': this.apiKey,
      'OK-ACCESS-SIGN': signature,
      'OK-ACCESS-TIMESTAMP': timestamp,
      'OK-ACCESS-PASSPHRASE': this.passphrase,
      'Content-Type': 'application/json'
    };

    try {
      const response = await axios({
        method,
        url: url + (queryString ? '?' + queryString : ''),
        headers,
        data: body || undefined,
        timeout: 10000
      });

      if (response.data.code === '0') {
        return { success: true, data: response.data.data };
      } else {
        this.logger.error(`OKX API 错误：${response.data.msg}`);
        return { success: false, error: response.data.msg };
      }
    } catch (error) {
      this.logger.error(`请求失败：${error.message}`);
      return { success: false, error: error.message };
    }
  }

  /**
   * 获取账户余额
   */
  async getBalance() {
    const result = await this.request('GET', '/account/balance');
    if (result.success && result.data && result.data.length > 0) {
      const usdtDetail = result.data[0].details.find(d => d.ccy === 'USDT');
      if (usdtDetail) {
        return {
          total: parseFloat(usdtDetail.eq) || 0,
          available: parseFloat(usdtDetail.availEq) || 0,
          currency: 'USDT'
        };
      }
    }
    return { total: 0, available: 0, currency: 'USDT' };
  }

  /**
   * 获取当前持仓
   */
  async getPosition(instId = 'BTC-USDT-SWAP') {
    const result = await this.request('GET', '/account/positions', { instId });
    if (result.success && result.data && result.data.length > 0) {
      const pos = result.data[0];
      return {
        instId: pos.instId,
        posSide: pos.posSide,
        pos: parseFloat(pos.pos) || 0,
        avgPx: parseFloat(pos.avgPx) || 0,
        upl: parseFloat(pos.upl) || 0,
        uplRatio: parseFloat(pos.uplRatio) || 0
      };
    }
    return null;
  }

  /**
   * 设置杠杆
   */
  async setLeverage(instId, leverage) {
    const data = {
      instId,
      lever: leverage.toString(),
      mgnMode: 'cross'
    };
    const result = await this.request('POST', '/account/set-leverage', {}, data);
    if (result.success) {
      this.logger.info(`✅ 杠杆已设置：${instId} ${leverage}x`);
    }
    return result;
  }

  /**
   * 开仓（下单）
   */
  async openPosition(signal) {
    const { instId, side, size, leverage } = signal;
    
    this.logger.info(`📊 准备开仓：${instId} ${side} ${size}`);
    
    // 1. 设置杠杆
    if (leverage) {
      await this.setLeverage(instId, leverage);
    }
    
    // 2. 市价单开仓
    const data = {
      instId,
      tdMode: 'cross',
      side,
      posSide: side === 'buy' ? 'long' : 'short',
      ordType: 'market',
      sz: size.toString()
    };
    
    this.logger.info(`📤 发送开仓订单：${JSON.stringify(data)}`);
    
    const result = await this.request('POST', '/trade/order', {}, data);
    
    if (result.success) {
      const orderId = result.data[0].ordId;
      this.logger.info(`✅ 开仓成功！订单 ID: ${orderId}`);
      
      // 记录持仓
      this.currentPosition = {
        instId,
        side,
        size: parseFloat(size),
        orderId,
        openTime: Date.now(),
        openPx: 0, // 市价单，实际成交价未知
        stopLoss: signal.stopLoss,
        takeProfit: signal.takeProfit
      };
      
      // 记录交易历史
      this.tradeHistory.push({
        type: 'open',
        instId,
        side,
        size: parseFloat(size),
        orderId,
        time: Date.now(),
        status: 'success'
      });
      
      return { success: true, orderId, position: this.currentPosition };
    } else {
      this.logger.error(`❌ 开仓失败：${result.error}`);
      return { success: false, error: result.error };
    }
  }

  /**
   * 平仓
   */
  async closePosition(reason = '手动平仓') {
    if (!this.currentPosition) {
      this.logger.warn('⚠️ 当前无持仓，无法平仓');
      return { success: false, error: '无持仓' };
    }
    
    const { instId, side, size } = this.currentPosition;
    const closeSide = side === 'buy' ? 'sell' : 'buy';
    
    this.logger.info(`📊 准备平仓：${instId} ${closeSide} ${size} (${reason})`);
    
    // 市价单平仓
    const data = {
      instId,
      tdMode: 'cross',
      side: closeSide,
      posSide: side === 'buy' ? 'long' : 'short',
      ordType: 'market',
      sz: size.toString(),
      reduceOnly: 'true'
    };
    
    this.logger.info(`📤 发送平仓订单：${JSON.stringify(data)}`);
    
    const result = await this.request('POST', '/trade/order', {}, data);
    
    if (result.success) {
      const orderId = result.data[0].ordId;
      this.logger.info(`✅ 平仓成功！订单 ID: ${orderId}`);
      
      // 记录交易历史
      this.tradeHistory.push({
        type: 'close',
        instId,
        side: closeSide,
        size: parseFloat(size),
        orderId,
        time: Date.now(),
        reason,
        status: 'success'
      });
      
      // 清空持仓
      const closedPosition = { ...this.currentPosition, closeTime: Date.now(), reason };
      this.currentPosition = null;
      
      return { success: true, orderId, position: closedPosition };
    } else {
      this.logger.error(`❌ 平仓失败：${result.error}`);
      return { success: false, error: result.error };
    }
  }

  /**
   * 设置止盈止损
   */
  async setStopLoss(instId, side, size, stopLossPx, takeProfitPx) {
    const triggerPrice = {
      type: 'last',
      price: stopLossPx.toString()
    };
    
    const data = {
      instId,
      mgnMode: 'cross',
      ccy: 'USDT',
      posSide: side === 'buy' ? 'long' : 'short',
      closeFraction: '1',
      tpTriggerPrice: takeProfitPx.toString(),
      tpOrdPx: '-1', // 市价单
      slTriggerPrice: stopLossPx.toString(),
      slOrdPx: '-1'  // 市价单
    };
    
    const result = await this.request('POST', '/trade/order-algo', {}, data);
    
    if (result.success) {
      this.logger.info(`✅ 止盈止损已设置：止损 ${stopLossPx}, 止盈 ${takeProfitPx}`);
    }
    
    return result;
  }

  /**
   * 检查止盈止损
   */
  async checkStopLoss() {
    if (!this.currentPosition) return;
    
    // 获取当前价格
    const ticker = await this.getTicker(this.currentPosition.instId);
    if (!ticker) return;
    
    const currentPrice = ticker.last;
    const { stopLoss, takeProfit, openPx, side } = this.currentPosition;
    
    // 计算盈亏比例
    let pnlRatio = 0;
    if (side === 'buy') {
      pnlRatio = (currentPrice - openPx) / openPx;
    } else {
      pnlRatio = (openPx - currentPrice) / openPx;
    }
    
    this.logger.info(`📊 持仓监控：当前价格 ${currentPrice}, 盈亏 ${pnlRatio * 100}%`);
    
    // 检查止损
    if (stopLoss && pnlRatio <= stopLoss) {
      this.logger.warn(`🛑 触发止损！盈亏 ${pnlRatio * 100}% <= ${stopLoss * 100}%`);
      await this.closePosition('止损');
      return;
    }
    
    // 检查止盈
    if (takeProfit && pnlRatio >= takeProfit) {
      this.logger.info(`✅ 触发止盈！盈亏 ${pnlRatio * 100}% >= ${takeProfit * 100}%`);
      await this.closePosition('止盈');
      return;
    }
  }

  /**
   * 获取实时价格
   */
  async getTicker(instId) {
    const result = await this.request('GET', '/market/ticker', { instId });
    if (result.success && result.data && result.data.length > 0) {
      return {
        last: parseFloat(result.data[0].last) || 0,
        bid: parseFloat(result.data[0].bidPx) || 0,
        ask: parseFloat(result.data[0].askPx) || 0
      };
    }
    return null;
  }

  /**
   * 获取交易历史
   */
  getTradeHistory() {
    return this.tradeHistory;
  }

  /**
   * 获取当前持仓
   */
  getCurrentPosition() {
    return this.currentPosition;
  }
}

module.exports = { OKXTrader };
