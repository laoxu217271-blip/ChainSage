/**
 * Frank-Wolfe 投资组合优化
 * 优化多个持仓的平衡
 */

class FrankWolfeOptimizer {
  constructor() {
    this.learningRate = 0.1;
    this.maxIterations = 100;
    this.convergenceThreshold = 1e-6;
  }

  /**
   * 优化投资组合
   * 
   * @param {Array} positions - 当前持仓
   * @param {Object} constraints - 约束条件
   */
  optimize(positions, constraints = {}) {
    const maxPositions = constraints.maxPositions || 5;
    const maxExposure = constraints.maxExposure || 0.5;
    
    // 初始化权重
    let weights = positions.map(() => 1 / positions.length);
    
    for (let i = 0; i < this.maxIterations; i++) {
      // 1. 计算梯度
      const gradient = this.calculateGradient(positions, weights);
      
      // 2. 找到最优方向
      const s = this.findOptimalDirection(gradient, maxPositions);
      
      // 3. 更新权重
      const gamma = this.learningRate;
      weights = weights.map((w, j) => (1 - gamma) * w + gamma * s[j]);
      
      // 4. 检查收敛
      if (this.hasConverged(weights, this.prevWeights || [])) {
        break;
      }
      
      this.prevWeights = [...weights];
    }
    
    // 应用最大风险敞口约束
    const totalExposure = weights.reduce((sum, w) => sum + w, 0);
    if (totalExposure > maxExposure) {
      weights = weights.map(w => w * (maxExposure / totalExposure));
    }
    
    return {
      weights,
      positions: positions.map((p, i) => ({
        ...p,
        weight: weights[i],
        allocation: weights[i] * 100
      }))
    };
  }

  /**
   * 计算梯度
   */
  calculateGradient(positions, weights) {
    return positions.map((p, i) => {
      // 梯度 = EV * 置信度
      return p.ev * (p.confidence / 100);
    });
  }

  /**
   * 找到最优方向
   */
  findOptimalDirection(gradient, maxPositions) {
    // 选择梯度最大的前 N 个位置
    const indexed = gradient.map((g, i) => ({ index: i, gradient: g }));
    const sorted = indexed.sort((a, b) => b.gradient - a.gradient);
    const topK = sorted.slice(0, maxPositions);
    
    // 创建方向向量
    const direction = new Array(gradient.length).fill(0);
    topK.forEach(item => {
      direction[item.index] = 1 / topK.length;
    });
    
    return direction;
  }

  /**
   * 检查收敛
   */
  hasConverged(current, prev) {
    if (prev.length === 0) return false;
    
    const diff = current.reduce((sum, w, i) => {
      return sum + Math.abs(w - (prev[i] || 0));
    }, 0);
    
    return diff < this.convergenceThreshold;
  }

  /**
   * 动态调整学习率
   */
  adjustLearningRate(iteration, totalIterations) {
    // 随着迭代次数增加，降低学习率
    return this.learningRate / (1 + iteration / totalIterations);
  }
}

module.exports = { FrankWolfeOptimizer };
