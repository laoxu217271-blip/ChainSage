/**
 * Kelly 公式仓位管理
 * 计算最优下注比例
 */

class KellyCriterion {
  constructor() {
    this.maxKellyFraction = 0.25; // 最大使用 25% Kelly（保守）
  }

  /**
   * 计算 Kelly 比例
   * f = (p × b - q) / b
   * 
   * @param {number} p - 获胜概率
   * @param {number} b - 赔率（净收益/下注）
   * @param {number} q - 失败概率 (1-p)
   */
  calculateKelly(p, b, q = 1 - p) {
    const kelly = (p * b - q) / b;
    
    // 限制在合理范围
    const safeKelly = Math.max(0, Math.min(kelly, this.maxKellyFraction));
    
    return {
      kelly,
      safeKelly,
      recommendation: this.getRecommendation(safeKelly)
    };
  }

  /**
   * 根据 EV 和赔率计算仓位
   */
  calculatePosition(ev, odds, bankroll) {
    // 将 EV 转换为获胜概率
    const p = 0.5 + ev / 2; // 简化转换
    const b = odds - 1; // 净赔率
    const q = 1 - p;
    
    const { kelly, safeKelly } = this.calculateKelly(p, b, q);
    
    // 计算实际下注金额
    const betAmount = bankroll * safeKelly;
    
    return {
      kelly,
      safeKelly,
      betAmount,
      bankroll,
      percentage: (safeKelly * 100).toFixed(2) + '%'
    };
  }

  /**
   * 获取建议
   */
  getRecommendation(kelly) {
    if (kelly <= 0) return '不下注';
    if (kelly < 0.05) return '小额下注 (5%)';
    if (kelly < 0.10) return '中等下注 (10%)';
    if (kelly < 0.20) return '较大下注 (20%)';
    return '重注 (25% 封顶)';
  }

  /**
   * 批量计算多个机会的仓位
   */
  allocateBankroll(bankroll, opportunities) {
    // 按 Kelly 比例分配资金
    const allocations = opportunities.map(opp => {
      const position = this.calculatePosition(opp.ev, opp.odds, bankroll);
      return {
        ...opp,
        ...position
      };
    });
    
    // 确保总仓位不超过限制
    const totalAllocation = allocations.reduce((sum, a) => sum + a.betAmount, 0);
    
    if (totalAllocation > bankroll * 0.5) {
      // 如果总仓位超过 50%，按比例缩减
      const scale = (bankroll * 0.5) / totalAllocation;
      return allocations.map(a => ({
        ...a,
        betAmount: a.betAmount * scale,
        adjusted: true
      }));
    }
    
    return allocations;
  }
}

module.exports = { KellyCriterion };
