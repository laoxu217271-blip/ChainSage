/**
 * 智能止损系统
 * 基于 Aaron Ruan 的 Polymarket 止损策略
 */

class SmartStopLoss {
  constructor() {
    this.avgBuyPrice = 0;
    this.cycleMaxAvgBuy = 0;
    this.stopLossPct = -0.30; // 默认 30% 止损
    this.armed = false;
    this.triggerCount = 0;
    this.requiredTicks = 2; // 连续 2 个 tick 确认
  }

  /**
   * 更新持仓信息
   */
  updatePosition(avgBuyPrice, cycleMaxAvgBuy) {
    this.avgBuyPrice = avgBuyPrice;
    this.cycleMaxAvgBuy = cycleMaxAvgBuy || avgBuyPrice;
    this.armed = true;
    this.triggerCount = 0;
  }

  /**
   * 计算触发价格
   * anchor = max(avgBuyPrice, cycleMaxAvgBuy)
   * triggerPrice = anchor × (1 + stopLossPct)
   */
  calculateTriggerPrice() {
    const anchor = Math.max(this.avgBuyPrice, this.cycleMaxAvgBuy);
    const triggerPrice = anchor * (1 + this.stopLossPct);
    
    return {
      anchor,
      triggerPrice,
      stopLossPct: this.stopLossPct
    };
  }

  /**
   * 公允价格门控
   * 优先用对手盘合成的 fairRef 判断
   */
  checkFairPrice(fairRef, triggerPrice) {
    if (fairRef > triggerPrice) {
      // 市场健康，重置 Armed 状态
      this.armed = false;
      this.triggerCount = 0;
      return {
        healthy: true,
        message: '市场健康，重置 Armed 状态'
      };
    }
    
    return {
      healthy: false,
      message: '市场价格低于触发价，继续检查'
    };
  }

  /**
   * 探针定价
   * 计算小样本（仓位 × 25%）的 FAK 可执行价格
   */
  calculateProbePrice(position, orderBook) {
    const probeSize = position * 0.25; // 25% 仓位
    const probePrice = this.simulateFAKExecution(probeSize, orderBook);
    
    return {
      probeSize,
      probePrice,
      executable: probePrice > 0
    };
  }

  /**
   * 模拟 FAK 执行
   */
  simulateFAKExecution(size, orderBook) {
    if (!orderBook || !orderBook.bids || orderBook.bids.length === 0) {
      return 0;
    }
    
    let remaining = size;
    let totalValue = 0;
    
    for (const bid of orderBook.bids) {
      const fillSize = Math.min(remaining, bid.size);
      totalValue += fillSize * bid.price;
      remaining -= fillSize;
      
      if (remaining <= 0) {
        break;
      }
    }
    
    // 如果无法完全成交，返回 0
    if (remaining > 0) {
      return 0;
    }
    
    return totalValue / size;
  }

  /**
   * 多周期确认
   * 连续 2 个 tick（≈6 秒）都满足条件才触发
   */
  confirmTrigger(probePrice, triggerPrice) {
    if (probePrice <= 0 || probePrice >= triggerPrice) {
      // 探针价格正常，重置计数
      this.triggerCount = 0;
      return {
        confirmed: false,
        message: '探针价格正常，重置计数'
      };
    }
    
    // 探针价格低于触发价，计数 +1
    this.triggerCount++;
    
    if (this.triggerCount >= this.requiredTicks) {
      return {
        confirmed: true,
        message: `连续${this.requiredTicks}个 tick 确认，触发止损`
      };
    }
    
    return {
      confirmed: false,
      message: `第${this.triggerCount}/${this.requiredTicks}次确认，继续监控`
    };
  }

  /**
   * 检查是否需要止损
   */
  checkStopLoss(position, orderBook, fairRef) {
    if (!this.armed) {
      return {
        shouldStop: false,
        message: '止损系统未激活'
      };
    }
    
    // 1. 计算触发价格
    const { triggerPrice } = this.calculateTriggerPrice();
    
    // 2. 公允价格门控
    const fairCheck = this.checkFairPrice(fairRef, triggerPrice);
    if (fairCheck.healthy) {
      return {
        shouldStop: false,
        message: fairCheck.message
      };
    }
    
    // 3. 探针定价
    const probeResult = this.calculateProbePrice(position, orderBook);
    if (!probeResult.executable) {
      return {
        shouldStop: false,
        message: '探针无法执行，流动性不足'
      };
    }
    
    // 4. 多周期确认
    const confirmResult = this.confirmTrigger(probeResult.probePrice, triggerPrice);
    if (!confirmResult.confirmed) {
      return {
        shouldStop: false,
        message: confirmResult.message
      };
    }
    
    // 5. 执行清仓
    return {
      shouldStop: true,
      message: confirmResult.message,
      action: '撤销所有挂单，提交 FAK 卖单'
    };
  }

  /**
   * 设置止损参数
   */
  setStopLossParams(stopLossPct = -0.30, requiredTicks = 2) {
    this.stopLossPct = stopLossPct;
    this.requiredTicks = requiredTicks;
  }

  /**
   * 重置止损系统
   */
  reset() {
    this.armed = false;
    this.triggerCount = 0;
    this.avgBuyPrice = 0;
    this.cycleMaxAvgBuy = 0;
  }
}

module.exports = { SmartStopLoss };
