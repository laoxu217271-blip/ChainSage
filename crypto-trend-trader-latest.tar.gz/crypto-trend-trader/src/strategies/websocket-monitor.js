/**
 * WebSocket 实时数据监控
 * 监听 Polymarket 价格变化
 */

const WebSocket = require('ws');

class PriceMonitor {
  constructor() {
    this.wsUrl = 'wss://ws-subscriptions-clob.polymarket.com/ws/market';
    this.ws = null;
    this.subscribedMarkets = new Set();
    this.callbacks = [];
  }

  /**
   * 连接 WebSocket
   */
  connect() {
    return new Promise((resolve, reject) => {
      this.ws = new WebSocket(this.wsUrl);
      
      this.ws.on('open', () => {
        console.log('✅ WebSocket 已连接');
        resolve();
      });
      
      this.ws.on('error', (error) => {
        console.error('❌ WebSocket 错误:', error);
        reject(error);
      });
      
      this.ws.on('message', (data) => {
        const message = JSON.parse(data.toString());
        this.handleMessage(message);
      });
      
      this.ws.on('close', () => {
        console.log('⚠️ WebSocket 已关闭，尝试重连...');
        setTimeout(() => this.connect(), 5000);
      });
    });
  }

  /**
   * 订阅市场
   */
  subscribe(marketId) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      const message = {
        type: 'subscribe',
        market: marketId
      };
      
      this.ws.send(JSON.stringify(message));
      this.subscribedMarkets.add(marketId);
      console.log('📡 已订阅市场:', marketId);
    }
  }

  /**
   * 处理消息
   */
  handleMessage(message) {
    console.log('📨 收到消息:', message);
    
    // 通知所有回调
    this.callbacks.forEach(callback => {
      try {
        callback(message);
      } catch (error) {
        console.error('回调错误:', error);
      }
    });
  }

  /**
   * 注册价格变化回调
   */
  onPriceChange(callback) {
    this.callbacks.push(callback);
  }

  /**
   * 监控价格异常波动
   */
  monitorVolatility(threshold = 0.05) {
    const priceHistory = new Map();
    
    this.onPriceChange((message) => {
      if (message.type !== 'price_update') return;
      
      const { marketId, price, timestamp } = message;
      
      if (!priceHistory.has(marketId)) {
        priceHistory.set(marketId, []);
      }
      
      const history = priceHistory.get(marketId);
      history.push({ price, timestamp });
      
      // 保留最近 10 条记录
      if (history.length > 10) {
        history.shift();
      }
      
      // 检测波动
      if (history.length >= 2) {
        const oldPrice = history[history.length - 2].price;
        const change = Math.abs(price - oldPrice) / oldPrice;
        
        if (change >= threshold) {
          console.log(`🚨 价格异常波动：${marketId} ${change * 100.toFixed(2)}%`);
          
          // 发送警报
          this.sendAlert({
            type: 'volatility_alert',
            marketId,
            oldPrice,
            newPrice: price,
            change: change * 100,
            timestamp
          });
        }
      }
    });
  }

  /**
   * 发送警报
   */
  sendAlert(alert) {
    console.log('🚨 警报:', alert);
    // TODO: 实现 Telegram 警报
  }

  /**
   * 断开连接
   */
  disconnect() {
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
  }
}

module.exports = { PriceMonitor };
