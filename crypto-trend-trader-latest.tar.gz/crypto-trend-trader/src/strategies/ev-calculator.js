/**
 * 期望值 (EV) 计算器
 * 找出市场定价错误机会
 */

class EVCalculator {
  constructor() {
    // 真实概率估计（可以通过历史数据/模型计算）
    this.trueProbabilityModel = null;
  }

  /**
   * 计算期望值
   * EV = p_true - market_price
   */
  calculateEV(trueProbability, marketPrice) {
    const ev = trueProbability - marketPrice;
    return {
      ev,
      edge: ev > 0 ? '有机会' : '无机会',
      roi: (ev / marketPrice * 100).toFixed(2) + '%'
    };
  }

  /**
   * 批量计算多个市场的 EV
   */
  calculateMultipleEV(markets) {
    return markets.map(market => ({
      marketId: market.id,
      marketName: market.name,
      marketPrice: market.price,
      trueProbability: this.estimateTrueProbability(market),
      ...this.calculateEV(
        this.estimateTrueProbability(market),
        market.price
      )
    }))
    .filter(m => m.ev > 0.05) // 只保留 EV > 5% 的机会
    .sort((a, b) => b.ev - a.ev); // 按 EV 排序
  }

  /**
   * 估计真实概率（需要根据具体市场定制）
   */
  estimateTrueProbability(market) {
    // TODO: 实现概率估计模型
    // 可以基于：
    // 1. 历史数据
    // 2. 外部数据源（如 Chainlink）
    // 3. 机器学习模型
    // 4. 专家预测聚合
    
    // 示例：简单移动平均
    return 0.5; // 默认 50%
  }
}

module.exports = { EVCalculator };
