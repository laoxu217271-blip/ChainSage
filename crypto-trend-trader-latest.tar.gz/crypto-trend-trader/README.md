# OKX 合约趋势交易机器人

> 基于 OKX Futures 的 BTC/ETH 趋势交易 + 订单流分析

## 🚀 快速开始

### 1. 安装依赖

```bash
cd /root/.openclaw/workspace/crypto-trend-trader
npm install
```

### 2. 配置 API

编辑 `config-live.js`：

```javascript
okx: {
  apiKey: '你的 API Key',
  apiSecret: '你的 API Secret',
  passphrase: '你的 Passphrase',
  testnet: true  // true=测试网，false=实盘
}
```

### 3. 启动

```bash
# 测试运行
node src/okx-live-trader.js

# 或后台运行
pm2 start src/okx-live-trader.js --name okx-trader
```

## 📊 策略

- **趋势跟踪** (40%)：均线交叉、MACD、布林带
- **订单流分析** (30%)：大单追踪、订单簿失衡
- **事件驱动** (20%)：新闻情绪、鲸鱼动向
- **均值回归** (10%)：统计套利

## 🛡️ 风控

| 参数 | 数值 |
|------|------|
| 单笔止损 | -3% |
| 单笔止盈 | +6% |
| 每日止损 | -10% |
| 最大仓位 | 50% |
| 连续亏损停止 | 3 次 |

## 📁 项目结构

```
crypto-trend-trader/
├── config-live.js            # OKX 配置
├── src/
│   ├── okx-live-trader.js    # OKX 交易主程序
│   ├── strategy/             # 策略引擎
│   ├── services/             # 服务层 (OKX API)
│   └── utils/                # 工具类
└── logs/                     # 日志目录
```

## ⚠️ 风险提示

- ⚠️ 区块链金融交易风险极高
- ⚠️ 可能亏损全部本金
- ⚠️ 先用测试网测试
- ⚠️ 只使用闲钱
