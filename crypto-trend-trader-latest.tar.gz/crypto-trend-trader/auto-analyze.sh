#!/bin/bash
cd /root/.openclaw/workspace/crypto-trend-trader

# 每 15 分钟分析一次
while true; do
  echo ""
  echo "=========================================="
  echo "📊 分析时间：$(date '+%Y-%m-%d %H:%M:%S')"
  echo "=========================================="
  
  node -e "
const axios = require('axios');

(async () => {
  try {
    // 获取真实 BTC 价格
    const priceResp = await axios.get('https://api.binance.com/api/v3/ticker/price', {
      params: { symbol: 'BTCUSDT' }
    });
    const price = parseFloat(priceResp.data.price);
    
    // 获取订单簿
    const orderBookResp = await axios.get('https://api.binance.com/api/v3/depth', {
      params: { symbol: 'BTCUSDT', limit: 20 }
    });
    
    // 计算买卖盘
    const bidVol = orderBookResp.data.bids.reduce((sum, b) => sum + parseFloat(b[1]), 0);
    const askVol = orderBookResp.data.asks.reduce((sum, a) => sum + parseFloat(a[1]), 0);
    const ratio = bidVol / askVol;
    
    // 分析
    let signal = '观望';
    let confidence = 50;
    
    if (ratio > 1.5) {
      signal = '买入';
      confidence = 50 + (ratio - 1) * 20;
    } else if (ratio < 0.67) {
      signal = '卖出';
      confidence = 50 + (1 - ratio) * 20;
    }
    
    console.log('💰 BTC 价格：$' + price.toFixed(2));
    console.log('📊 订单簿:');
    console.log('  买盘：' + bidVol.toFixed(2) + ' BTC');
    console.log('  卖盘：' + askVol.toFixed(2) + ' BTC');
    console.log('  买卖比：' + ratio.toFixed(2));
    console.log('');
    console.log('🎯 分析结果:');
    console.log('  信号：' + signal);
    console.log('  置信度：' + Math.min(confidence, 95).toFixed(1) + '%');
    console.log('  建议：' + (confidence >= 75 ? '✅ 可交易' : '⚠️ 观望'));
    
  } catch (error) {
    console.error('❌ 错误:', error.message);
  }
})();
" 2>&1 | tee -a logs/analysis.log

  sleep 900  # 15 分钟
done
