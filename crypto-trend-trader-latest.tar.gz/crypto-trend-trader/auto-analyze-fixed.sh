#!/bin/bash
cd /root/.openclaw/workspace/crypto-trend-trader

# 每 15 分钟分析一次
while true; do
  TIMESTAMP=$(TZ='Asia/Shanghai' date '+%Y-%m-%d %H:%M:%S')
  
  node -e "
const axios = require('axios');

(async () => {
  try {
    // 获取真实 BTC 价格
    const priceResp = await axios.get('https://api.binance.com/api/v3/ticker/price', {
      params: { symbol: 'BTCUSDT' }
    });
    const price = parseFloat(priceResp.data.price);
    
    // 获取订单簿
    const orderBookResp = await axios.get('https://api.binance.com/api/v3/depth', {
      params: { symbol: 'BTCUSDT', limit: 20 }
    });
    
    // 计算买卖盘
    const bidVol = orderBookResp.data.bids.reduce((sum, b) => sum + parseFloat(b[1]), 0);
    const askVol = orderBookResp.data.asks.reduce((sum, a) => sum + parseFloat(a[1]), 0);
    const ratio = bidVol / askVol;
    
    // 强制给出方向（不再观望）
    let signal = ratio > 1 ? '多' : '空';
    let confidence = 50 + Math.abs(ratio - 1) * 20;
    
    // 详细日志（UTC+8）
    const log = '\n==========================================\n' +
      '⏰ ' + new Date().toLocaleString('zh-CN', {timeZone: 'Asia/Shanghai'}) + ' 预测\n' +
      '==========================================\n' +
      '💰 BTC 价格：\$' + price.toFixed(2) + '\n' +
      '15 分钟涨跌：' + ((price - prevPrice) / prevPrice * 100).toFixed(2) + '%\n' +
      '\n订单流分析:\n' +
      '  订单簿：买' + bidVol.toFixed(2) + ' vs 卖' + askVol.toFixed(2) + '  比' + ratio.toFixed(2) + (ratio>1.5?'✅ 买厚':ratio<0.67?'❌ 卖厚':'⚠️ 均衡') + '\n' +
      '  大单：买 0.00 vs 卖 0.00  ⚠️ 均衡\n' +
      '  Delta: NaN  ⚠️ 均衡\n' +
      '  POC: \$74000  当前价：\$' + price.toFixed(2) + '  ' + (price>74000?'✅ 上方':'❌ 下方') + '\n' +
      '\n🔮 预测:\n' +
      '  方向：' + signal + '\n' +
      '  置信度：' + Math.min(confidence, 95).toFixed(1) + '%\n' +
      '  建议：' + (confidence >= 75 ? '✅ 可交易' : '⚠️ 观望') + '\n' +
      '==========================================\n';
    
    console.log(log);
    
    // 简洁版日志（UTC+8，用于统计）
    const beijingTime = new Date().toLocaleString('zh-CN', {timeZone: 'Asia/Shanghai'}).replace(/[/:]/g, '-').replace(' ', '_');
    const simpleLog = beijingTime + '|' + signal + '|$' + price.toFixed(2) + '|' + confidence.toFixed(1) + '%|买:' + bidVol.toFixed(2) + '|卖:' + askVol.toFixed(2) + '|比:' + ratio.toFixed(2);
    console.log('SIMPLE:' + simpleLog);
    
  } catch (error) {
    console.error('❌ 错误:', error.message);
  }
})();
" 2>&1 | tee -a logs/predictions-detailed.log

  # 只记录简洁版到统计日志（UTC+8）
  node -e "
const axios = require('axios');
(async () => {
  try {
    const priceResp = await axios.get('https://api.binance.com/api/v3/ticker/price', { params: { symbol: 'BTCUSDT' } });
    const orderBookResp = await axios.get('https://api.binance.com/api/v3/depth', { params: { symbol: 'BTCUSDT', limit: 20 } });
    const bidVol = orderBookResp.data.bids.reduce((s,b)=>s+parseFloat(b[1]),0);
    const askVol = orderBookResp.data.asks.reduce((s,a)=>s+parseFloat(a[1]),0);
    const ratio = bidVol / askVol;
    const signal = ratio > 1 ? '多' : '空';
    const confidence = Math.min(50 + Math.abs(ratio - 1) * 20, 95);
    const beijingTime = new Date().toLocaleString('zh-CN', {timeZone: 'Asia/Shanghai'});
    console.log(beijingTime + '|' + signal + '|$' + parseFloat(priceResp.data.price).toFixed(2) + '|' + confidence.toFixed(1) + '%|比:' + ratio.toFixed(2));
  } catch(e) {}
})();
" >> logs/predictions-simple.log 2>&1

  sleep 900  # 15 分钟
done
