# Binance 实盘交易机器人 - 使用说明

## ⚠️ 重要警告

**⚠️ 这是实盘交易程序，使用真实资金！**
**⚠️ 务必先使用测试网测试！**
**⚠️ 只使用闲钱，做好亏损准备！**

---

## 🚀 快速开始

### 1. 获取 Binance API Key

1. 登录 Binance：https://www.binance.com/
2. 进入个人中心 → API 管理
3. 创建 API Key
4. 权限设置：
   - ✅ 读取权限
   - ✅  Futures 交易权限
   - ❌ 提现权限（不要开启）
5. 记录以下信息：
   - API Key
   - API Secret

### 2. 配置文件

编辑 `config-live.js`：

```javascript
module.exports = {
  binance: {
    apiKey: '你的 API Key',
    apiSecret: '你的 API Secret',
    testnet: true  // true=测试网，false=实盘
  },
  
  // ... 其他配置
};
```

### 3. 测试网测试

**⚠️ 务必先测试！**

```bash
# 确保 testnet: true
cd /root/.openclaw/workspace/crypto-trend-trader

# 启动测试网交易
node src/binance-live-trader.js
```

### 4. 实盘交易

**测试通过后，切换到实盘：**

```bash
# 修改 config-live.js 中 testnet: false
node src/binance-live-trader.js
```

---

## 📊 配置说明

### 交易配置

```javascript
trading: {
  // 交易对
  symbols: ['BTCUSDT', 'ETHUSDT'],
  
  // 杠杆倍数
  leverage: {
    'BTCUSDT': 10,  // BTC 10 倍
    'ETHUSDT': 8    // ETH 8 倍
  },
  
  // 交易间隔（15 分钟）
  interval: 15 * 60 * 1000
}
```

### 风控配置

```javascript
risk: {
  // 初始资金
  initialBalance: 10,  // 10 USDT
  
  // 单笔最大亏损（3%）
  maxLossPerTrade: 0.03,
  
  // 每日最大亏损（10%）
  maxLossPerDay: 0.10,
  
  // 最大仓位（50%）
  maxPosition: 0.50,
  
  // 止损（-3%）
  stopLoss: -0.03,
  
  // 止盈（+6%）
  takeProfit: 0.06,
  
  // 连续亏损停止（3 次）
  maxConsecutiveLosses: 3
}
```

---

## 📊 运行模式

### 模拟盘模式
```bash
# 使用历史数据测试
node test/predict.js
```

### 测试网模式
```javascript
// config-live.js
testnet: true  // 测试网
```

```bash
node src/binance-live-trader.js
```

### 实盘模式
```javascript
// config-live.js
testnet: false  // 实盘
```

```bash
node src/binance-live-trader.js
```

---

## 🛡️ 风控措施

### 自动止损
- 每笔交易止损：-3%
- 触发自动平仓

### 自动止盈
- 每笔交易止盈：+6%
- 触发自动平仓

### 追踪止盈
- 盈利超过 3% 后启动
- 回撤 3% 自动平仓

### 每日止损
- 每日最大亏损：10%
- 触发后停止交易 24 小时

### 连续亏损
- 连续亏损 3 次
- 停止交易 24 小时

### 紧急停止
```bash
# 按 Ctrl+C 停止程序
# 自动平掉所有仓位
```

---

## 📊 日志查看

```bash
# 查看实时日志
tail -f logs/live-trading.log

# 查看最近 100 行
tail -100 logs/live-trading.log
```

---

## ⚠️ 风险提示

### 杠杆风险
- 10-20 倍杠杆极高风险
- 可能爆仓亏损全部本金
- 建议从低杠杆开始（5-10 倍）

### 市场风险
- 区块链金融波动极大
- 可能瞬间大幅波动
- 建议只用闲钱

### 技术风险
- 网络延迟
- API 故障
- 程序 bug

### 建议
1. **先测试网测试至少 1 周**
2. **从小资金开始（10-50 USDT）**
3. **逐步增加资金**
4. **持续监控和调整**

---

## 📞 常见问题

### Q: 如何停止交易？
A: 按 Ctrl+C 停止程序

### Q: 如何查看盈亏？
A: 查看日志文件 `logs/live-trading.log`

### Q: 爆仓了怎么办？
A: 降低杠杆，减少仓位，重新测试

### Q: 如何调整策略？
A: 修改 `config-live.js` 中的策略配置

---

## ⚠️ 最后警告

**⚠️ 区块链金融交易风险极高！**
**⚠️ 可能亏损全部本金！**
**⚠️ 只使用闲钱！**
**⚠️ 做好亏损准备！**

---

**祝你交易顺利！谨慎交易！** 🚀
