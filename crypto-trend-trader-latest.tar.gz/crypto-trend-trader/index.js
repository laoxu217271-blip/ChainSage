/**
 * OKX 合约趋势交易机器人
 * 基于 OKX Futures 的 BTC/ETH 趋势交易 + 订单流分析
 * 
 * @author 老许
 * @version 1.0.0
 */

require('dotenv').config();
const { OKXLiveTrader } = require('./src/okx-live-trader');
const { Logger } = require('./src/utils/logger');

class TradingBot {
  constructor() {
    this.logger = new Logger();
    this.trader = null;
    this.isRunning = false;
  }

  async start() {
    this.logger.info('🚀 OKX 趋势交易机器人启动...');
    this.trader = new OKXLiveTrader();
    this.isRunning = true;
    this.logger.info('✅ 机器人运行中...');
    await this.trader.start();
  }

  async stop() {
    this.logger.info('⏹️ 停止机器人...');
    this.isRunning = false;
    if (this.trader) {
      await this.trader.stop();
    }
    this.logger.info('✅ 机器人已停止');
  }
}

if (require.main === module) {
  const bot = new TradingBot();
  process.on('SIGINT', async () => {
    await bot.stop();
    process.exit(0);
  });
  bot.start().catch(console.error);
}

module.exports = { TradingBot };
