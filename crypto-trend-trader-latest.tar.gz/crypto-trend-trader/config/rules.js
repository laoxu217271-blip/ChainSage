/**
 * 交易规则配置
 */

module.exports = {
  // 交易时间
  TRADING_HOURS: {
    start: '00:00',
    end: '23:59',
    timezone: 'UTC'
  },
  
  // 市场筛选
  MARKET_FILTER: {
    minLiquidity: 1000,
    minVolume: 500,
    maxSpread: 0.05,
    minTimeToExpiry: 3600
  },
  
  // 入场条件
  ENTRY_CONDITIONS: {
    minConfidence: 0.7,
    minScore: 0.5,
    requireMultipleSignals: true
  },
  
  // 出场条件
  EXIT_CONDITIONS: {
    takeProfit: 2.0,
    stopLoss: 0.5,
    timeExit: 7200,
    expiryExit: 7200
  },
  
  // 仓位管理
  POSITION_SIZING: {
    basePercent: 10,
    maxPercent: 20,
    scaleIn: true,
    scaleOut: true
  },
  
  // 风控规则
  RISK_RULES: {
    maxDailyLoss: 20,
    maxConcurrent: 5,
    maxExposure: 60,
    requireStopLoss: true
  },
  
  // 日志配置
  LOGGING: {
    level: 'info',
    file: 'logs/trading.log',
    maxSize: '10MB',
    maxFiles: 5
  }
};
