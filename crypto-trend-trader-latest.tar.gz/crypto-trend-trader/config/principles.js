/**
 * 核心原则配置
 */

module.exports = {
  // 简洁优先
  SIMPLICITY_FIRST: true,
  
  // 不懒惰
  NO_LAZINESS: true,
  
  // 最小影响
  MINIMAL_IMPACT: true,
  
  // 计划优先
  PLAN_FIRST: {
    enabled: true,
    minSteps: 3,
    requireSpec: true
  },
  
  // 使用子代理
  USE_SUBAGENTS: {
    enabled: true,
    maxConcurrent: 5
  },
  
  // 从纠正中学习
  LEARN_FROM_CORRECTIONS: {
    enabled: true,
    saveToLessons: true,
    generateRules: true
  },
  
  // 完成前验证
  VERIFY_BEFORE_COMPLETE: {
    enabled: true,
    runTests: true,
    checkLogs: true,
    compareBehavior: true
  },
  
  // 要求优雅
  DEMAND_ELEGANCE: {
    enabled: true,
    forComplexity: 'non-trivial'
  },
  
  // 自主修复 Bug
  AUTO_FIX_BUGS: {
    enabled: true,
    analyzeLogs: true,
    runTests: true
  }
};
