/**
 * Web 服务器 - OKX 真实数据源（优化版）
 * ⚠️ 所有数据必须来自真实 API，禁止使用 Math.random()
 * ⚡ 优化：缓存数据，减少 API 调用
 */

const express = require('express');
const path = require('path');
const axios = require('axios');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3001;

// 从 config-live.js 读取 OKX API 配置
const config = require('./config-live');

const OKX_CONFIG = {
  apiKey: config.okx.apiKey || '',
  apiSecret: config.okx.apiSecret || '',
  passphrase: config.okx.passphrase || '',
  testnet: config.okx.testnet || false,
  baseURL: 'https://www.okx.com'
};

// 数据缓存（减少 API 调用）
const cache = {
  ticker: { data: null, timestamp: 0, ttl: 1000 },      // 1 秒缓存
  klines: { data: null, timestamp: 0, ttl: 5000 },      // 5 秒缓存
  orderBook: { data: null, timestamp: 0, ttl: 2000 },   // 2 秒缓存
  trades: { data: null, timestamp: 0, ttl: 3000 }       // 3 秒缓存
};

app.use(express.json());

// 禁用缓存头
app.use((req, res, next) => {
  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  next();
});

app.use(express.static(path.join(__dirname, 'public')));

// OKX API 请求函数（带缓存）
async function okxRequest(endpoint, params = {}, signed = false) {
  try {
    const config = {
      method: 'GET',
      url: `${OKX_CONFIG.baseURL}/api/v5/${endpoint}`,
      params,
      headers: { 'Content-Type': 'application/json' },
      timeout: 5000  // 5 秒超时
    };
    
    if (signed && OKX_CONFIG.apiKey) {
      const timestamp = new Date().toISOString();
      const method = 'GET';
      const path = `/api/v5/${endpoint}`;
      const queryString = Object.keys(params).map(k => `${k}=${params[k]}`).join('&');
      const body = queryString ? `?${queryString}` : '';
      const signStr = timestamp + method + path + body;
      
      const signature = crypto
        .createHmac('sha256', OKX_CONFIG.apiSecret)
        .update(signStr)
        .digest('base64');
      
      config.headers['OK-ACCESS-KEY'] = OKX_CONFIG.apiKey;
      config.headers['OK-ACCESS-SIGN'] = signature;
      config.headers['OK-ACCESS-TIMESTAMP'] = timestamp;
      config.headers['OK-ACCESS-PASSPHRASE'] = OKX_CONFIG.passphrase;
    }
    
    const response = await axios(config);
    
    // 严格错误检查
    if (!response || !response.data) {
      console.error(`OKX API 响应为空：${endpoint}`);
      return null;
    }
    
    if (response.data.code === '0') {
      const result = response.data.data;
      console.log(`✓ OKX API 成功：${endpoint}, 数据量：${Array.isArray(result) ? result.length : 'object'}`);
      return result;
    } else {
      console.error(`OKX API 错误：${endpoint}, code: ${response.data.code}, msg: ${response.data.msg}`);
      return null;
    }
  } catch (error) {
    console.error(`OKX 请求失败：${endpoint}, ${error.message}`);
    return null;
  }
}

// 获取缓存数据
function getCached(key) {
  const item = cache[key];
  if (item && item.data && Date.now() - item.timestamp < item.ttl) {
    return item.data;
  }
  return null;
}

// 设置缓存数据
function setCached(key, data) {
  const defaultTtl = {
    'ticker_BTC-USDT': 1000,
    'ticker_ETH-USDT': 1000,
    'klines': 5000,
    'orderBook': 2000,
    'trades': 3000
  };
  
  cache[key] = {
    data,
    timestamp: Date.now(),
    ttl: defaultTtl[key] || 5000
  };
  console.log(`✓ 缓存已设置：${key}`);
}

// 获取实时价格（带缓存）
async function getTicker(symbol = 'BTC-USDT') {
  // 不同交易对使用不同缓存键
  const cacheKey = `ticker_${symbol}`;
  const cached = getCached(cacheKey);
  if (cached) return cached;
  
  const data = await okxRequest('market/ticker', { instId: symbol });
  
  if (!data || data.length === 0) {
    console.error(`获取 ${symbol} 价格失败`);
    return null;
  }
  
  const ticker = {
    symbol,
    last: parseFloat(data[0].last) || 0,
    bid: parseFloat(data[0].bidPx) || 0,
    ask: parseFloat(data[0].askPx) || 0,
    high24h: parseFloat(data[0].high24h) || 0,
    low24h: parseFloat(data[0].low24h) || 0,
    change24h: parseFloat(data[0].chg24h) || 0
  };
  
  console.log(`✓ ${symbol} 价格：${ticker.last}`);
  setCached(cacheKey, ticker);
  return ticker;
}

// 获取 K 线数据（带缓存）
async function getKlines(symbol = 'BTC-USDT', interval = '15m', limit = 100) {
  const cached = getCached('klines');
  if (cached) return cached;
  
  const data = await okxRequest('market/candles', {
    instId: symbol,
    bar: interval,
    limit
  });
  
  if (!data) return [];
  
  const klines = data.map(k => ({
    timestamp: parseInt(k[0]),
    open: parseFloat(k[1]) || 0,
    high: parseFloat(k[2]) || 0,
    low: parseFloat(k[3]) || 0,
    close: parseFloat(k[4]) || 0,
    volume: parseFloat(k[5]) || 0
  }));
  
  setCached('klines', klines);
  return klines;
}

// 获取订单簿（带缓存）
async function getOrderBook(symbol = 'BTC-USDT', depth = 20) {
  const cached = getCached('orderBook');
  if (cached) return cached;
  
  const data = await okxRequest('market/books', {
    instId: symbol,
    sz: depth.toString()
  });
  
  if (!data || data.length === 0) return null;
  
  const orderBook = {
    bids: data[0].bids.map(b => ({
      price: parseFloat(b[0]),
      size: parseFloat(b[1])
    })),
    asks: data[0].asks.map(a => ({
      price: parseFloat(a[0]),
      size: parseFloat(a[1])
    }))
  };
  
  setCached('orderBook', orderBook);
  return orderBook;
}

// 获取最近成交（带缓存）
async function getTrades(symbol = 'BTC-USDT', limit = 100) {
  const cached = getCached('trades');
  if (cached) return cached;
  
  const data = await okxRequest('market/trades', {
    instId: symbol,
    limit: limit.toString()
  });
  
  if (!data) return [];
  
  const trades = data.map(t => ({
    price: parseFloat(t.px) || 0,
    size: parseFloat(t.sz) || 0,
    side: t.side || 'unknown',
    timestamp: parseInt(t.ts) || Date.now()
  }));
  
  setCached('trades', trades);
  return trades;
}

// 获取账户余额
async function getAccountBalance() {
  if (!OKX_CONFIG.apiKey) {
    return { total: 0, available: 0, currency: 'USDT' };
  }
  
  try {
    const data = await okxRequest('account/balance', {}, true);
    
    if (!data || !Array.isArray(data) || data.length === 0) {
      console.log('⚠️ 账户余额数据为空');
      return { total: 0, available: 0, currency: 'USDT' };
    }
    
    const usdtDetail = data[0].details.find(d => d.ccy === 'USDT');
    if (!usdtDetail) {
      console.log('⚠️ 未找到 USDT 余额');
      return { total: 0, available: 0, currency: 'USDT' };
    }
    
    const result = {
      total: parseFloat(usdtDetail.eq) || 0,
      available: parseFloat(usdtDetail.availEq) || 0,
      currency: 'USDT'
    };
    console.log(`✓ 账户余额：${result.total} USDT`);
    return result;
  } catch (error) {
    console.error(`获取账户余额失败：${error.message}`);
    return { total: 0, available: 0, currency: 'USDT' };
  }
}

// 获取持仓信息
async function getPosition() {
  if (!OKX_CONFIG.apiKey) return null;
  
  try {
    const data = await okxRequest('account/positions', { instId: 'BTC-USDT-SWAP' }, true);
    
    if (!data || !Array.isArray(data) || data.length === 0) {
      console.log('⚠️ 持仓数据为空');
      return null;
    }
    
    const pos = data[0];
    const result = {
      symbol: pos.instId,
      direction: pos.posSide === 'long' ? 'LONG' : 'SHORT',
      size: parseFloat(pos.pos) || 0,
      entryPrice: parseFloat(pos.avgPx) || 0,
      unrealizedPnl: parseFloat(pos.upl) || 0
    };
    console.log(`✓ 持仓：${result.symbol} ${result.direction}`);
    return result;
  } catch (error) {
    console.error(`获取持仓失败：${error.message}`);
    return null;
  }
}

// 计算 RSI 指标
function calculateRSI(prices, period = 14) {
  if (prices.length < period + 1) return 50;
  
  let gains = 0, losses = 0;
  for (let i = prices.length - period; i < prices.length; i++) {
    const change = prices[i] - prices[i - 1];
    if (change > 0) gains += change;
    else losses -= change;
  }
  
  const avgGain = gains / period;
  const avgLoss = losses / period || 1;
  const rs = avgGain / avgLoss;
  return 100 - (100 / (1 + rs));
}

// 计算乖离率（BIAS）
function calculateBIAS(price, ma) {
  if (!ma || ma === 0) return 0;
  return ((price - ma) / ma) * 100;
}

// 量能状态判断
function getVolumeStatus(currentVol, avgVol) {
  if (!avgVol || avgVol === 0) return { status: '正常', score: 0 };
  const ratio = currentVol / avgVol;
  if (ratio > 1.5) return { status: '放量', score: 0.4 };
  if (ratio > 1.2) return { status: '温和放量', score: 0.2 };
  if (ratio < 0.7) return { status: '缩量', score: -0.2 };
  return { status: '正常', score: 0 };
}

// 趋势状态判断（参考 daily_stock_analysis）
function getTrendStatus(ma5, ma10, ma20) {
  if (ma5 > ma10 && ma10 > ma20) return { status: '多头排列', score: 0.3 };
  if (ma5 < ma10 && ma10 < ma20) return { status: '空头排列', score: -0.3 };
  if (ma5 > ma10 && ma10 < ma20) return { status: '弱势多头', score: 0.1 };
  if (ma5 < ma10 && ma10 > ma20) return { status: '弱势空头', score: -0.1 };
  return { status: '盘整', score: 0 };
}

// 市场情绪分析（参考 daily_stock_analysis 情绪分析算法）
function analyzeMarketSentiment(trades, orderBook, klines) {
  let sentimentScore = 0;
  const reasons = [];
  
  // 1. 交易情绪分析（主动买入/卖出比例）
  if (trades && trades.length > 0) {
    const buyTrades = trades.filter(t => t.side === 'buy');
    const sellTrades = trades.filter(t => t.side === 'sell');
    const buyRatio = buyTrades.length / trades.length;
    const buyVolume = buyTrades.reduce((sum, t) => sum + t.size, 0);
    const sellVolume = sellTrades.reduce((sum, t) => sum + t.size, 0);
    const volumeRatio = buyVolume / (buyVolume + sellVolume || 1);
    
    // 交易笔数情绪
    if (buyRatio > 0.65) {
      sentimentScore += 0.15;
      reasons.push(`主动买入占比${Math.round(buyRatio*100)}%（偏多）`);
    } else if (buyRatio < 0.35) {
      sentimentScore -= 0.15;
      reasons.push(`主动卖出占比${Math.round((1-buyRatio)*100)}%（偏空）`);
    }
    
    // 交易量情绪
    if (volumeRatio > 0.65) {
      sentimentScore += 0.15;
      reasons.push(`买入量占比${Math.round(volumeRatio*100)}%（资金流入）`);
    } else if (volumeRatio < 0.35) {
      sentimentScore -= 0.15;
      reasons.push(`卖出量占比${Math.round((1-volumeRatio)*100)}%（资金流出）`);
    }
  }
  
  // 2. 订单簿情绪分析（买卖盘深度对比）
  if (orderBook) {
    const bidDepth = orderBook.bids.slice(0, 10).reduce((sum, b) => sum + b.size, 0);
    const askDepth = orderBook.asks.slice(0, 10).reduce((sum, a) => sum + a.size, 0);
    const depthRatio = bidDepth / (bidDepth + askDepth || 1);
    
    if (depthRatio > 0.65) {
      sentimentScore += 0.1;
      reasons.push(`买单深度${Math.round(depthRatio*100)}%（支撑强）`);
    } else if (depthRatio < 0.35) {
      sentimentScore -= 0.1;
      reasons.push(`卖单深度${Math.round((1-depthRatio)*100)}%（压力大）`);
    }
  }
  
  // 3. 价格动量情绪（最近 10 根 K 线涨跌比）
  if (klines && klines.length >= 10) {
    const recentCloses = klines.slice(-10).map(k => k.close);
    let upCount = 0, downCount = 0;
    for (let i = 1; i < recentCloses.length; i++) {
      if (recentCloses[i] > recentCloses[i-1]) upCount++;
      else if (recentCloses[i] < recentCloses[i-1]) downCount++;
    }
    
    if (upCount > downCount + 2) {
      sentimentScore += 0.1;
      reasons.push(`近 10 根 K 线${upCount}涨${downCount}跌（偏多）`);
    } else if (downCount > upCount + 2) {
      sentimentScore -= 0.1;
      reasons.push(`近 10 根 K 线${downCount}跌${upCount}涨（偏空）`);
    }
  }
  
  // 限制情绪分数范围 -1 到 +1
  sentimentScore = Math.max(-1, Math.min(1, sentimentScore));
  
  // 情绪状态描述
  let sentimentStatus = '中性';
  if (sentimentScore > 0.5) sentimentStatus = '极度乐观';
  else if (sentimentScore > 0.3) sentimentStatus = '乐观';
  else if (sentimentScore > 0.1) sentimentStatus = '偏多';
  else if (sentimentScore < -0.5) sentimentStatus = '极度悲观';
  else if (sentimentScore < -0.3) sentimentStatus = '悲观';
  else if (sentimentScore < -0.1) sentimentStatus = '偏空';
  
  return {
    score: sentimentScore,
    status: sentimentStatus,
    reasons: reasons.slice(0, 5)  // 最多返回 5 个原因
  };
}

// === 策略 1：SMA 均线交叉 ===
function calculateSmaCrossover(klines, fast = 20, slow = 50) {
  if (!klines || klines.length < slow) return 0;
  
  const closes = klines.map(k => k.close);
  
  // 计算快慢 SMA
  const smaFast = closes.slice(-fast).reduce((a, b) => a + b, 0) / fast;
  const smaSlow = closes.slice(-slow).reduce((a, b) => a + b, 0) / slow;
  
  // 前视偏差避免：使用前一天的 SMA 交叉
  const prevSmaFast = closes.slice(-fast - 1, -1).reduce((a, b) => a + b, 0) / fast;
  const prevSmaSlow = closes.slice(-slow - 1, -1).reduce((a, b) => a + b, 0) / slow;
  
  // 金叉：快线上穿慢线
  if (prevSmaFast <= prevSmaSlow && smaFast > smaSlow) return 1;
  // 死叉：快线下穿慢线
  if (prevSmaFast >= prevSmaSlow && smaFast < smaSlow) return -1;
  // 维持现状
  if (smaFast > smaSlow) return 0.5;
  if (smaFast < smaSlow) return -0.5;
  return 0;
}

// === 策略 2：动量策略 ===
function calculateMomentum(klines, window = 20) {
  if (!klines || klines.length < window + 1) return 0;
  
  const closes = klines.map(k => k.close);
  
  // 动量：过去 N 天的对数收益率
  const momentum = Math.log(closes[closes.length - 1] / closes[closes.length - window - 1]);
  
  // 前视偏差避免：使用前一天的动量
  const prevMomentum = Math.log(closes[closes.length - 2] / closes[closes.length - window - 2]);
  
  // 动量为正且增强
  if (momentum > 0 && momentum > prevMomentum) return 1;
  // 动量为正但减弱
  if (momentum > 0) return 0.5;
  // 动量为负且减弱
  if (momentum < 0 && momentum < prevMomentum) return -1;
  // 动量为负但增强
  if (momentum < 0) return -0.5;
  return 0;
}

// === 策略 3：均值回归策略 ===
function calculateMeanReversion(klines, window = 20, threshold = 1.0) {
  if (!klines || klines.length < window) return 0;
  
  const closes = klines.map(k => k.close);
  const currentPrice = closes[closes.length - 1];
  
  // 滚动均值和标准差
  const mean = closes.slice(-window).reduce((a, b) => a + b, 0) / window;
  const variance = closes.slice(-window).reduce((sum, price) => sum + Math.pow(price - mean, 2), 0) / window;
  const std = Math.sqrt(variance);
  
  // Z-Score
  const zscore = (currentPrice - mean) / std;
  
  // 前视偏差避免：使用前一天的 Z-Score
  const prevZscore = (closes[closes.length - 2] - mean) / std;
  
  // Z-Score < -threshold：价格太低，买入信号
  if (zscore < -threshold) return 1;
  // Z-Score 从低位回归
  if (prevZscore < -threshold && zscore > -threshold) return 0.5;
  // Z-Score > threshold：价格太高，卖出信号
  if (zscore > threshold) return -1;
  // Z-Score 从高位回归
  if (prevZscore > threshold && zscore < threshold) return -0.5;
  return 0;
}

// 计算置信度（真实公式，无随机数）- 增强版（含情绪分析）
function calculateConfidence(klines, orderBook, trades) {
  if (!klines || klines.length < 2) return 50;
  
  const closes = klines.map(k => k.close);
  const currentPrice = closes[closes.length - 1];
  
  // === 1. 趋势分析（20% 权重）===
  const ema7 = calculateEMA(closes, 7);
  const ema25 = calculateEMA(closes, 25);
  const ma5 = closes.slice(-5).reduce((a, b) => a + b, 0) / 5;
  const ma10 = closes.slice(-10).reduce((a, b) => a + b, 0) / 10;
  const ma20 = closes.slice(-20).reduce((a, b) => a + b, 0) / 20;
  
  const trendStatus = getTrendStatus(ma5, ma10, ma20);
  let trendScore = trendStatus.score;
  
  const ema12 = calculateEMA(closes, 12);
  const ema26 = calculateEMA(closes, 26);
  const macd = ema12 - ema26;
  if (macd > 0) trendScore += 0.2; else if (macd < 0) trendScore -= 0.2;
  
  // === 2. 乖离率检测（15% 权重）===
  const biasMA5 = calculateBIAS(currentPrice, ma5);
  let biasScore = 0;
  if (biasMA5 > 5) biasScore = -0.3;
  else if (biasMA5 < -5) biasScore = 0.2;
  else if (biasMA5 > 3) biasScore = -0.1;
  else if (biasMA5 < -3) biasScore = 0.1;
  
  // === 3. RSI 指标（15% 权重）===
  const rsi14 = calculateRSI(closes, 14);
  let rsiScore = 0;
  if (rsi14 > 70) rsiScore = -0.3;
  else if (rsi14 < 30) rsiScore = 0.3;
  else if (rsi14 > 60) rsiScore = -0.1;
  else if (rsi14 < 40) rsiScore = 0.1;
  
  // === 4. 订单流分析（20% 权重）===
  let orderFlowScore = 0;
  if (orderBook) {
    const bidVol = orderBook.bids.slice(0, 5).reduce((s, b) => s + b.size, 0);
    const askVol = orderBook.asks.slice(0, 5).reduce((s, a) => s + a.size, 0);
    const ratio = bidVol / askVol;
    if (ratio > 2) orderFlowScore += 0.4;
    else if (ratio < 0.5) orderFlowScore -= 0.4;
    else if (ratio > 1.5) orderFlowScore += 0.2;
    else if (ratio < 0.67) orderFlowScore -= 0.2;
  }
  
  // === 5. 量能分析（15% 权重）===
  let volumeScore = 0;
  if (klines.length > 10) {
    const volumes = klines.map(k => k.volume);
    const avgVolume = volumes.slice(0, -1).reduce((a, b) => a + b, 0) / (volumes.length - 1);
    const currentVolume = volumes[volumes.length - 1];
    const volumeStatus = getVolumeStatus(currentVolume, avgVolume);
    volumeScore = volumeStatus.score;
  }
  
  // === 6. 市场情绪分析（新增！15% 权重）===
  const sentiment = analyzeMarketSentiment(trades, orderBook, klines);
  const sentimentScore = sentiment.score;
  
  // === 综合置信度计算（集成三种经典策略）===
  // 计算三种经典策略信号
  const smaSignal = calculateSmaCrossover(klines, 20, 50);      // SMA 交叉
  const momentumSignal = calculateMomentum(klines, 20);         // 动量策略
  const mrSignal = calculateMeanReversion(klines, 20, 1.0);     // 均值回归
  
  let confidence = 50 + 
    (smaSignal * 15) +            // SMA 交叉策略 15%
    (momentumSignal * 15) +       // 动量策略 15%
    (mrSignal * 15) +             // 均值回归策略 15%
    (trendScore * 10) +           // 趋势分析 10%
    (biasScore * 10) +            // 乖离率 10%
    (rsiScore * 10) +             // RSI 10%
    (orderFlowScore * 10) +       // 订单流 10%
    (volumeScore * 5) +           // 量能 5%
    (sentimentScore * 10);        // 情绪 10%
  
  // 信号一致性加分
  const signals = [trendScore, biasScore, rsiScore, orderFlowScore, volumeScore, sentimentScore];
  const positive = signals.filter(s => s > 0).length;
  const negative = signals.filter(s => s < 0).length;
  if (positive === 6 || negative === 6) confidence += 10;
  else if (positive >= 5 || negative >= 5) confidence += 5;
  
  return Math.max(0, Math.min(100, Math.round(confidence)));
}

function calculateEMA(prices, period) {
  const k = 2 / (period + 1);
  let ema = prices[0];
  for (let i = 1; i < prices.length; i++) {
    ema = prices[i] * k + ema * (1 - k);
  }
  return ema;
}

// API: 状态（优化版 - 并行请求 + 缓存）
app.get('/api/status', async (req, res) => {
  try {
    console.log('\n=== 开始获取状态 ===');
    
    // 并行获取数据
    const [btcTicker, ethTicker, klines, orderBook, trades, balance, position] = await Promise.all([
      getTicker('BTC-USDT').catch(e => { console.error('BTC 失败:', e.message); return null; }),
      getTicker('ETH-USDT').catch(e => { console.error('ETH 失败:', e.message); return null; }),
      getKlines('BTC-USDT', '15m', 100).catch(e => { console.error('K 线失败:', e.message); return []; }),
      getOrderBook('BTC-USDT', 20).catch(e => { console.error('订单簿失败:', e.message); return null; }),
      getTrades('BTC-USDT', 100).catch(e => { console.error('成交失败:', e.message); return []; }),
      getAccountBalance().catch(e => { console.error('余额失败:', e.message); return { total: 0, available: 0, currency: 'USDT' }; }),
      getPosition().catch(e => { console.error('持仓失败:', e.message); return null; })
    ]);
    
    console.log('✓ 所有数据获取完成');
    console.log(`  BTC: ${btcTicker ? btcTicker.last : 'null'}`);
    console.log(`  ETH: ${ethTicker ? ethTicker.last : 'null'}`);
    console.log(`  K 线：${klines ? klines.length : 0} 条`);
    console.log(`  余额：${balance ? balance.total : 0}`);
    
    const btcPrice = btcTicker && btcTicker.last ? btcTicker.last : 0;
    const ethPrice = ethTicker && ethTicker.last ? ethTicker.last : 0;
    
    // 计算情绪分析
    const sentiment = analyzeMarketSentiment(trades, orderBook, klines);
    const confidence = calculateConfidence(klines, orderBook, trades);
    
    let prediction = { direction: '等待', confidence: 0 };
    if (klines && klines.length >= 2) {
      const current = klines[klines.length - 1].close;
      const prev = klines[klines.length - 2].close;
      prediction = {
        direction: current > prev ? '做多' : '做空',
        confidence,
        timestamp: new Date().toLocaleTimeString()
      };
    }
    
    // 计算下次 15 分钟 K 线收盘时间
    const now = new Date();
    const minutes = now.getMinutes();
    const next15Min = Math.floor(minutes / 15) * 15 + 15;
    const nextScanTime = new Date(now);
    nextScanTime.setMinutes(next15Min <= 59 ? next15Min : 0, 0, 0);
    if (next15Min > 59) nextScanTime.setHours(nextScanTime.getHours() + 1);
    
    const nextScan = `${nextScanTime.getHours().toString().padStart(2,'0')}:${nextScanTime.getMinutes().toString().padStart(2,'0')}:${nextScanTime.getSeconds().toString().padStart(2,'0')}`;
    
    // 计算技术指标
    const closes = klines && klines.length > 0 ? klines.map(k => k.close) : [];
    const currentPriceVal = closes[closes.length - 1] || btcPrice;
    
    // RSI 指标
    const rsiValue = closes.length >= 15 ? calculateRSI(closes, 14) : 50;
    
    // 乖离率
    const ma5 = closes.length >= 5 ? closes.slice(-5).reduce((a, b) => a + b, 0) / 5 : currentPriceVal;
    const biasValue = ((currentPriceVal - ma5) / ma5) * 100;
    
    // 趋势状态
    const ma10 = closes.length >= 10 ? closes.slice(-10).reduce((a, b) => a + b, 0) / 10 : currentPriceVal;
    const ma20 = closes.length >= 20 ? closes.slice(-20).reduce((a, b) => a + b, 0) / 20 : currentPriceVal;
    const trendStatusObj = getTrendStatus(ma5, ma10, ma20);
    
    // 量能状态
    const volumes = klines && klines.length > 10 ? klines.map(k => k.volume) : [];
    const avgVolume = volumes.slice(0, -1).reduce((a, b) => a + b, 0) / (volumes.length - 1) || 1;
    const currentVolume = volumes[volumes.length - 1] || 0;
    const volumeRatio = currentVolume / avgVolume;
    let volumeStatus = '正常';
    if (volumeRatio > 1.5) volumeStatus = '放量';
    else if (volumeRatio > 1.2) volumeStatus = '温和放量';
    else if (volumeRatio < 0.8) volumeStatus = '缩量';
    
    const result = {
      running: true,
      balance: balance ? balance.total : 0,
      dailyPnL: 0,
      totalTrades: 0,
      winTrades: 0,
      winRate: 0,
      position: position || null,
      nextScan,
      mode: OKX_CONFIG.testnet ? 'testnet' : 'live',
      btcPrice,
      ethPrice,
      currentPrice: btcPrice,
      prediction,
      sentiment: {
        score: Math.round(sentiment.score * 100) / 100,
        status: sentiment.status,
        reasons: sentiment.reasons
      },
      indicators: {
        rsi: rsiValue > 0 ? rsiValue.toFixed(2) : '50.00',
        biasMA5: biasValue.toFixed(2),
        trendStatus: trendStatusObj.status,
        volumeStatus: volumeStatus
      },
      timestamp: new Date().toISOString()
    };
    
    console.log('✓ 状态 API 响应成功');
    res.json(result);
  } catch (error) {
    console.error('❌ 状态 API 错误:', error);
    res.json({
      running: false,
      balance: 0,
      dailyPnL: 0,
      totalTrades: 0,
      winTrades: 0,
      winRate: 0,
      position: null,
      mode: 'error',
      btcPrice: 0,
      ethPrice: 0,
      currentPrice: 0,
      prediction: { direction: '错误', confidence: 0 },
      error: error.message
    });
  }
});

// API: K 线数据
app.get('/api/klines', async (req, res) => {
  try {
    const { symbol = 'BTC-USDT', interval = '15m', limit = '100' } = req.query;
    const klines = await getKlines(symbol, interval, parseInt(limit));
    
    res.json({
      success: true,
      symbol,
      interval,
      count: klines.length,
      data: klines
    });
  } catch (error) {
    console.error('K 线 API 错误:', error);
    res.json({
      success: false,
      error: error.message,
      data: []
    });
  }
});

// API: 预测记录
app.get('/api/predictions', async (req, res) => {
  try {
    const [klines, orderBook, trades] = await Promise.all([
      getKlines('BTC-USDT', '15m', 100),
      getOrderBook('BTC-USDT', 20),
      getTrades('BTC-USDT', 100)
    ]);
    
    const currentPrice = klines.length > 0 ? klines[klines.length - 1].close : 0;
    const prevPrice = klines.length > 1 ? klines[klines.length - 2].close : 0;
    const confidence = calculateConfidence(klines, orderBook, trades);
    
    const prediction = {
      time: new Date().toLocaleTimeString(),
      symbol: 'BTC-USDT',
      direction: currentPrice > prevPrice ? '做多' : '做空',
      confidence,
      result: '待结算',
      entryPrice: currentPrice
    };
    
    res.json({
      success: true,
      data: [prediction]
    });
  } catch (error) {
    res.json({
      success: false,
      error: error.message,
      data: []
    });
  }
});

// 全局交易器实例
let globalTrader = null;
let tradingInterval = null;

// API: 启动交易
app.post('/api/start', async (req, res) => {
  console.log('📥 收到启动交易请求');
  try {
    if (globalTrader && globalTrader.isRunning) {
      return res.json({ success: false, error: '交易已在运行中' });
    }
    
    const { OKXLiveTrader } = require('./src/okx-live-trader');
    globalTrader = new OKXLiveTrader();
    
    // 初始化（不启动无限循环）
    const initialized = await globalTrader.init();
    if (!initialized) {
      return res.json({ success: false, error: '初始化失败' });
    }
    
    globalTrader.isRunning = true;
    
    // 后台定时执行（每 15 分钟）
    console.log('✅ 交易已启动，每 15 分钟执行一次');
    res.json({ success: true, message: '交易已启动，每 15 分钟执行一次' });
    
    // 立即执行一次
    setTimeout(async () => {
      await globalTrader.tradingLoop();
    }, 1000);
    
  } catch (error) {
    console.error('启动交易失败:', error);
    res.json({ success: false, error: error.message });
  }
});

// API: 停止交易
app.post('/api/stop', async (req, res) => {
  console.log('📥 收到停止交易请求');
  try {
    if (globalTrader) {
      globalTrader.isRunning = false;
      if (tradingInterval) {
        clearInterval(tradingInterval);
        tradingInterval = null;
      }
      res.json({ success: true, message: '交易已停止' });
    } else {
      res.json({ success: false, error: '交易未运行' });
    }
  } catch (error) {
    console.error('停止交易失败:', error);
    res.json({ success: false, error: error.message });
  }
});

// API: 获取交易状态
app.get('/api/trade-status', (req, res) => {
  res.json({
    isRunning: globalTrader ? globalTrader.isRunning : false,
    hasTrader: !!globalTrader
  });
});

// API: 停止交易
app.post('/api/stop', async (req, res) => {
  console.log('📥 收到停止交易请求');
  try {
    const { OKXLiveTrader } = require('./src/okx-live-trader');
    const trader = new OKXLiveTrader();
    await trader.stop();
    res.json({ success: true, message: '交易已停止' });
  } catch (error) {
    console.error('停止交易失败:', error);
    res.json({ success: false, error: error.message });
  }
});

// API: 获取交易状态
app.get('/api/trade-status', (req, res) => {
  try {
    const { OKXLiveTrader } = require('./src/okx-live-trader');
    const trader = new OKXLiveTrader();
    res.json({ success: true, status: trader.getStatus() });
  } catch (error) {
    res.json({ success: false, error: error.message });
  }
});

// API: 日志
app.get('/api/logs', (req, res) => {
  const fs = require('fs');
  const logFile = path.join(__dirname, 'logs', 'live-trading.log');
  
  if (fs.existsSync(logFile)) {
    const logs = fs.readFileSync(logFile, 'utf8');
    const lines = logs.split('\n').filter(l => l.trim()).slice(-100);
    res.json({ success: true, logs: lines });
  } else {
    res.json({ success: true, logs: [] });
  }
});

// 首页 - 添加版本号防止缓存
app.get('/', (req, res) => {
  res.setHeader('X-Version', '20260325-2');
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// 启动服务器
app.listen(PORT, '0.0.0.0', () => {
  console.log(`\n🚀 Web 服务器已启动：http://0.0.0.0:${PORT}`);
  console.log(`⚡ 优化模式：缓存启用，响应更快`);
  console.log(`📊 API 端点:`);
  console.log(`   GET /api/status - 账户状态（真实 OKX 数据）`);
  console.log(`   GET /api/klines - K 线数据（真实 OKX 数据）`);
  console.log(`   GET /api/predictions - 预测记录（真实计算置信度）`);
  console.log(`   GET /api/logs - 运行日志`);
  console.log(`\n⚠️ 所有数据来自真实 API，无随机数据\n`);
});

module.exports = { app };
