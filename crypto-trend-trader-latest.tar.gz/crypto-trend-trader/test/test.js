/**
 * 测试脚本
 * 测试订单流策略功能
 */

const { OrderFlowStrategy } = require('../src/strategy/orderflow-strategy');
const { TrendStrategy } = require('../src/strategy/trend-strategy');
const { RiskManager } = require('../src/risk/risk-manager');

async function runTests() {
  console.log('🧪 开始测试...\n');
  
  let passed = 0;
  let failed = 0;
  
  // 测试 1：订单流策略
  console.log('测试 1：订单流策略分析');
  try {
    const orderFlow = new OrderFlowStrategy();
    await orderFlow.initialize();
    
    const mockMarket = {
      id: 'test-market',
      currentPrice: 0.55,
      title: 'Test Market'
    };
    
    const result = await orderFlow.analyze(mockMarket);
    
    if (typeof result.score === 'number') {
      console.log('✅ 通过 - 返回有效评分\n');
      passed++;
    } else {
      console.log('❌ 失败 - 评分无效\n');
      failed++;
    }
  } catch (error) {
    console.log('❌ 失败 -', error.message, '\n');
    failed++;
  }
  
  // 测试 2：趋势策略
  console.log('测试 2：趋势策略分析');
  try {
    const trend = new TrendStrategy();
    await trend.initialize();
    
    const mockMarket = {
      currentPrice: 0.55
    };
    
    const result = await trend.analyze(mockMarket);
    
    if (typeof result.score === 'number') {
      console.log('✅ 通过 - 返回有效评分\n');
      passed++;
    } else {
      console.log('❌ 失败 - 评分无效\n');
      failed++;
    }
  } catch (error) {
    console.log('❌ 失败 -', error.message, '\n');
    failed++;
  }
  
  // 测试 3：风控管理
  console.log('测试 3：风控管理');
  try {
    const risk = new RiskManager();
    await risk.initialize();
    
    const canTrade = risk.canTrade();
    
    if (typeof canTrade === 'boolean') {
      console.log('✅ 通过 - 风控检查正常\n');
      passed++;
    } else {
      console.log('❌ 失败 - 风控检查异常\n');
      failed++;
    }
  } catch (error) {
    console.log('❌ 失败 -', error.message, '\n');
    failed++;
  }
  
  // 总结
  console.log('===================');
  console.log(`测试结果：${passed} 通过，${failed} 失败`);
  console.log('===================\n');
  
  if (failed === 0) {
    console.log('🎉 所有测试通过！可以启动机器人\n');
  } else {
    console.log('⚠️ 部分测试失败，请检查代码\n');
  }
}

// 运行测试
runTests().catch(console.error);
